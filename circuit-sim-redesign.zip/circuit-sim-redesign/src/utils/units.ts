// ─────────────────────────────────────────────────────────────────────────────
// units.ts — SI prefix parsing
//
// Converts human-readable component values to base SI units:
//   "10kΩ"  → 10_000   (ohms)
//   "4.7kΩ" → 4_700
//   "220Ω"  → 220
//   "1MΩ"   → 1_000_000
//   "9V"    → 9
//   "1.5V"  → 1.5
//   "100µF" → 1e-4
//   "10mH"  → 0.01
//   "2.2nF" → 2.2e-9
// ─────────────────────────────────────────────────────────────────────────────

const SI_PREFIXES: Record<string, number> = {
  T: 1e12,
  G: 1e9,
  M: 1e6,
  k: 1e3,
  K: 1e3,  // tolerant of uppercase K
  '': 1,
  m: 1e-3,
  u: 1e-6,
  µ: 1e-6, // U+00B5 micro sign
  μ: 1e-6, // U+03BC greek small letter mu
  n: 1e-9,
  p: 1e-12,
}

/**
 * Parse a value string into a base SI number.
 * Strips trailing unit letters (Ω, V, F, H, A) and applies SI prefix.
 * Returns NaN if the string cannot be parsed.
 */
export function parseValue(raw: string | number): number {
  if (typeof raw === 'number') return raw
  if (!raw) return NaN

  const s = String(raw).trim()

  // Match: optional sign, digits/decimal, optional SI prefix, optional unit
  // e.g. "-4.7kΩ" → ["-4.7", "k", "Ω"]
  const m = s.match(/^([+-]?[\d.]+)\s*([TGMkKmuµμnp]?)\s*[ΩVFHAΩohmsvoltsfaradshenrysamps]*/i)
  if (!m) {
    // Last-ditch: try plain parseFloat
    return parseFloat(s)
  }

  const mantissa = parseFloat(m[1])
  const prefix = m[2] ?? ''
  const multiplier = SI_PREFIXES[prefix] ?? 1

  return mantissa * multiplier
}

/**
 * Format a number back to a human-readable string with the most appropriate
 * SI prefix (used for displaying simulation results).
 */
export function formatValue(value: number, unit: string, decimals = 3): string {
  const abs = Math.abs(value)
  const sign = value < 0 ? '-' : ''

  if (abs === 0) return `0 ${unit}`
  if (abs >= 1e9)  return `${sign}${(abs / 1e9).toFixed(decimals)}G${unit}`
  if (abs >= 1e6)  return `${sign}${(abs / 1e6).toFixed(decimals)}M${unit}`
  if (abs >= 1e3)  return `${sign}${(abs / 1e3).toFixed(decimals)}k${unit}`
  if (abs >= 1)    return `${sign}${abs.toFixed(decimals)}${unit}`
  if (abs >= 1e-3) return `${sign}${(abs / 1e-3).toFixed(decimals)}m${unit}`
  if (abs >= 1e-6) return `${sign}${(abs / 1e-6).toFixed(decimals)}µ${unit}`
  if (abs >= 1e-9) return `${sign}${(abs / 1e-9).toFixed(decimals)}n${unit}`
  return `${sign}${(abs / 1e-12).toFixed(decimals)}p${unit}`
}

export function formatVoltage(v: number): string { return formatValue(v, 'V') }
export function formatCurrent(i: number): string { return formatValue(i, 'A') }
export function formatResistance(r: number): string { return formatValue(r, 'Ω') }
export function formatPower(p: number): string { return formatValue(p, 'W') }
