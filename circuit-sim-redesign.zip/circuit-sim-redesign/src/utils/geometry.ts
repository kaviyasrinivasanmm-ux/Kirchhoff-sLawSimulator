import * as THREE from 'three'
import type { Vec3, CircuitNode, ConnectionPoint } from '@/types'

// ─────────────────────────────────────────────────────────────────────────────
// Geometry utilities — pure functions, no React, no store access
// ─────────────────────────────────────────────────────────────────────────────

export const vec3Zero = (): Vec3 => ({ x: 0, y: 0, z: 0 })

export const vec3Add = (a: Vec3, b: Vec3): Vec3 => ({
  x: a.x + b.x,
  y: a.y + b.y,
  z: a.z + b.z,
})

export const vec3FromArray = ([x, y, z]: [number, number, number]): Vec3 => ({ x, y, z })
export const vec3ToArray = (v: Vec3): [number, number, number] => [v.x, v.y, v.z]

export const vec3Dist = (a: Vec3, b: Vec3): number => {
  const dx = a.x - b.x
  const dy = a.y - b.y
  const dz = a.z - b.z
  return Math.sqrt(dx * dx + dy * dy + dz * dz)
}

// ── Snapping ──────────────────────────────────────────────────────────────────

export const snapToGrid = (value: number, gridSize: number): number => {
  if (gridSize <= 0) return value
  return Math.round(value / gridSize) * gridSize
}

export const snapVec3 = (v: Vec3, gridSize: number): Vec3 => ({
  x: snapToGrid(v.x, gridSize),
  y: v.y, // Y is always the table height — never snap vertically
  z: snapToGrid(v.z, gridSize),
})

// ── World-space ray → Y-plane intersection ────────────────────────────────────

const _plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0)
const _target = new THREE.Vector3()

export function rayToPlane(
  ray: THREE.Ray,
  planeY: number
): { x: number; z: number } | null {
  _plane.constant = -planeY
  const hit = ray.intersectPlane(_plane, _target)
  if (!hit) return null
  return { x: hit.x, z: hit.z }
}

// ── Bounding-sphere radius for each component type ──────────────────────────

export const COMPONENT_BOUNDS: Record<string, number> = {
  resistor: 0.7,
  'voltage-source': 0.8,
  capacitor: 0.6,
  inductor: 0.7,
  ground: 0.4,
  wire: 0.2,
}

// ─────────────────────────────────────────────────────────────────────────────
// Connection point helpers
//
// Each component exposes connection points (terminals) at known world offsets
// relative to its position. These are used by the smart wire tool.
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Returns all connection points (terminal world positions) for a given node.
 * Offsets match the exact terminal geometry in Resistor.tsx and Battery.tsx.
 */
export function getConnectionPoints(node: CircuitNode): ConnectionPoint[] {
  switch (node.type) {
    case 'resistor': {
      // Resistor rotated 90° on Z: local X axis → world Z axis
      // Terminals at local ±1.065 X → world ±1.065 Z
      return [
        {
          nodeId: node.id,
          terminal: 'negative',
          worldPosition: { x: node.position.x, y: node.position.y, z: node.position.z - 1.065 },
        },
        {
          nodeId: node.id,
          terminal: 'positive',
          worldPosition: { x: node.position.x, y: node.position.y, z: node.position.z + 1.065 },
        },
      ]
    }
    case 'voltage-source': {
      // Battery terminals at local Y ±0.91/0.86 → world Y offsets from center
      return [
        {
          nodeId: node.id,
          terminal: 'positive',
          worldPosition: { x: node.position.x, y: node.position.y + 0.91, z: node.position.z },
        },
        {
          nodeId: node.id,
          terminal: 'negative',
          worldPosition: { x: node.position.x, y: node.position.y - 0.86, z: node.position.z },
        },
      ]
    }
    default:
      return []
  }
}

/**
 * From a world-space cursor position and list of all nodes, find the
 * nearest valid connection point within `maxRadius` units.
 * Returns null if nothing is close enough.
 */
export function findNearestConnectionPoint(
  cursor: Vec3,
  nodes: CircuitNode[],
  maxRadius = 1.4,         // generous hitbox radius
  excludeNodeId?: string   // skip self-connections
): ConnectionPoint | null {
  let nearest: ConnectionPoint | null = null
  let nearestDist = maxRadius

  for (const node of nodes) {
    if (node.id === excludeNodeId) continue
    const pts = getConnectionPoints(node)
    for (const pt of pts) {
      const d = vec3Dist(cursor, pt.worldPosition)
      if (d < nearestDist) {
        nearestDist = d
        nearest = pt
      }
    }
  }

  return nearest
}

/**
 * Build a clean L-shaped / stepped wire path between two 3D points.
 * Avoids a simple straight line by routing through a midpoint arc.
 */
export function buildWirePath(from: Vec3, to: Vec3): Vec3[] {
  // Horizontal L-route: go horizontal first, then vertical
  const midX = (from.x + to.x) / 2
  const liftY = Math.max(from.y, to.y) + 0.12

  // Use a 5-point path for smooth CatmullRom routing
  return [
    { x: from.x, y: from.y, z: from.z },
    { x: from.x, y: liftY, z: from.z },
    { x: midX,   y: liftY, z: (from.z + to.z) / 2 },
    { x: to.x,   y: liftY, z: to.z },
    { x: to.x,   y: to.y,  z: to.z },
  ]
}
