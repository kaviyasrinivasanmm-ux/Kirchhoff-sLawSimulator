// Monotonically increasing counter ensures IDs are unique within a session.
// Prefix is the component type so IDs are human-readable in the store.
let _counter = 0

export const generateId = (prefix = 'node'): string =>
  `${prefix}_${Date.now()}_${_counter++}`
