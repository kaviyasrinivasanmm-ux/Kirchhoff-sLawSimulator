export type ComponentType =
  | 'resistor'
  | 'capacitor'
  | 'inductor'
  | 'voltage-source'
  | 'ground'
  | 'wire'

export interface Vec3 { x: number; y: number; z: number }

export interface CircuitNode {
  id: string
  type: ComponentType
  position: Vec3
  rotation: Vec3
  properties: Record<string, number | string>
}

export interface Wire {
  id: string
  from: string
  to: string
  points: Vec3[]
}

export interface CircuitState {
  nodes: CircuitNode[]
  wires: Wire[]
  selectedId: string | null
  simulating: boolean
}

export type InteractionMode = 'idle' | 'placing' | 'dragging' | 'wiring'

export interface DragState {
  nodeId: string
  offsetX: number
  offsetZ: number
}

export interface PlacementGhost {
  type: ComponentType
  position: Vec3
  rotation: Vec3
  snapped: boolean
}

// Connection point: a terminal anchor on a component in world-space
export interface ConnectionPoint {
  nodeId: string
  terminal: 'positive' | 'negative'
  worldPosition: Vec3
}
