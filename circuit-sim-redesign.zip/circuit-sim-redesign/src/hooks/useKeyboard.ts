import { useEffect, useRef } from 'react'
import useCircuitStore from '@/store/useCircuitStore'
import useInteractionStore from '@/store/useInteractionStore'

const SNAP_CYCLE = [0.5, 0.25, 0] as const

export function useKeyboard(): void {
  const deleteSelected = useRef(useCircuitStore.getState().deleteSelected)
  const rotateNode = useRef(useCircuitStore.getState().rotateNode)
  const selectNode = useRef(useCircuitStore.getState().selectNode)
  const clearGhost = useRef(useInteractionStore.getState().clearGhost)
  const cancelWiring = useRef(useInteractionStore.getState().cancelWiring)
  const disableWireTool = useRef(useInteractionStore.getState().disableWireTool)
  const setSnapGrid = useRef(useInteractionStore.getState().setSnapGrid)

  useEffect(() => {
    return useCircuitStore.subscribe((s) => {
      deleteSelected.current = s.deleteSelected
      rotateNode.current = s.rotateNode
      selectNode.current = s.selectNode
    })
  }, [])

  useEffect(() => {
    return useInteractionStore.subscribe((s) => {
      clearGhost.current = s.clearGhost
      cancelWiring.current = s.cancelWiring
      disableWireTool.current = s.disableWireTool
      setSnapGrid.current = s.setSnapGrid
    })
  }, [])

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (
        e.target instanceof HTMLInputElement ||
        e.target instanceof HTMLTextAreaElement
      ) return

      switch (e.key) {
        case 'Delete':
        case 'Backspace': {
          e.preventDefault()
          deleteSelected.current()
          break
        }

        case 'Escape': {
          const { mode, wireTool } = useInteractionStore.getState()
          if (mode === 'wiring') {
            cancelWiring.current()
            disableWireTool.current()
          } else if (wireTool) {
            disableWireTool.current()
          } else if (mode === 'placing') {
            clearGhost.current()
          } else {
            selectNode.current(null)
          }
          break
        }

        case 'r':
        case 'R': {
          const { selectedId } = useCircuitStore.getState()
          if (selectedId) {
            rotateNode.current(selectedId, Math.PI / 2)
          }
          break
        }

        case 'g':
        case 'G': {
          const current = useInteractionStore.getState().snapGrid
          const idx = SNAP_CYCLE.indexOf(current as typeof SNAP_CYCLE[number])
          const next = SNAP_CYCLE[(idx + 1) % SNAP_CYCLE.length]
          setSnapGrid.current(next)
          break
        }

        // W shortcut to toggle wire tool
        case 'w':
        case 'W': {
          const { wireTool, mode, enableWireTool, cancelWiring: cw, disableWireTool: dwt } = useInteractionStore.getState()
          if (wireTool || mode === 'wiring') {
            cw()
            dwt()
          } else {
            enableWireTool()
          }
          break
        }
      }
    }

    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [])
}

type KeyMap = Record<string, (e: KeyboardEvent) => void>
export function useKeyMap(keyMap: KeyMap): void {
  const mapRef = useRef(keyMap)
  mapRef.current = keyMap
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const action = mapRef.current[e.key]
      if (action) action(e)
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [])
}
