import { useCallback } from 'react'
import type { ThreeEvent } from '@react-three/fiber'
import useCircuitStore from '@/store/useCircuitStore'
import useInteractionStore from '@/store/useInteractionStore'
import { rayToPlane, snapToGrid } from '@/utils/geometry'

export interface PlacementHandlers {
  onPointerMove: (e: ThreeEvent<PointerEvent>) => void
  onClick: (e: ThreeEvent<MouseEvent>) => void
  onContextMenu: (e: ThreeEvent<MouseEvent>) => void
}

function defaultProps(type: string): Record<string, number | string> {
  switch (type) {
    case 'resistor': return { value: '1kΩ' }
    case 'voltage-source': return { voltage: '9V', chargeLevel: 1 }
    case 'capacitor': return { value: '100µF' }
    case 'inductor': return { value: '10mH' }
    default: return {}
  }
}

export function usePlacement(): PlacementHandlers {
  const addNode = useCircuitStore((s) => s.addNode)
  const selectNode = useCircuitStore((s) => s.selectNode)
  const updateGhost = useInteractionStore((s) => s.updateGhost)
  const clearGhost = useInteractionStore((s) => s.clearGhost)

  const onPointerMove = useCallback((e: ThreeEvent<PointerEvent>) => {
    const { mode, activeTool, snapGrid } = useInteractionStore.getState()
    if (mode !== 'placing' || !activeTool) return
    const hit = rayToPlane(e.ray, 0.14)
    if (!hit) return
    const sx = snapToGrid(hit.x, snapGrid)
    const sz = snapToGrid(hit.z, snapGrid)
    updateGhost({ x: sx, y: 0.14, z: sz }, snapGrid > 0)
  }, [updateGhost])

  const onClick = useCallback((e: ThreeEvent<MouseEvent>) => {
    const { mode, activeTool, snapGrid } = useInteractionStore.getState()
    if (mode !== 'placing' || !activeTool) return
    e.stopPropagation()
    const hit = rayToPlane(e.ray, 0.14)
    if (!hit) return
    const x = snapToGrid(hit.x, snapGrid)
    const z = snapToGrid(hit.z, snapGrid)
    const id = addNode({
      type: activeTool,
      position: { x, y: 0.14, z },
      rotation: { x: 0, y: 0, z: Math.PI / 2 },
      properties: defaultProps(activeTool),
    })
    selectNode(id)
  }, [addNode, selectNode])

  const onContextMenu = useCallback((e: ThreeEvent<MouseEvent>) => {
    const { mode } = useInteractionStore.getState()
    if (mode !== 'placing') return
    e.stopPropagation()
    clearGhost()
  }, [clearGhost])

  return { onPointerMove, onClick, onContextMenu }
}
