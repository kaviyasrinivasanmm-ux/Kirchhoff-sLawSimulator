import useCircuitStore from '@/store/useCircuitStore'
import useInteractionStore from '@/store/useInteractionStore'
import type { CircuitNode } from '@/types'

// ─────────────────────────────────────────────────────────────────────────────
// useSelection
//
// Convenience hook that aggregates selection + hover state from both stores
// into a single coherent object for UI components (PropertiesPanel, etc.).
// ─────────────────────────────────────────────────────────────────────────────

export interface SelectionState {
  selectedId: string | null
  selectedNode: CircuitNode | null
  hoveredId: string | null
  selectNode: (id: string | null) => void
  deleteSelected: () => void
  rotateSelected: () => void
}

export function useSelection(): SelectionState {
  const selectedId = useCircuitStore((s) => s.selectedId)
  const nodes = useCircuitStore((s) => s.nodes)
  const selectNode = useCircuitStore((s) => s.selectNode)
  const deleteSelected = useCircuitStore((s) => s.deleteSelected)
  const rotateNode = useCircuitStore((s) => s.rotateNode)

  const hoveredId = useInteractionStore((s) => s.hoveredId)

  const selectedNode = nodes.find((n) => n.id === selectedId) ?? null

  const rotateSelected = () => {
    if (selectedId) rotateNode(selectedId, Math.PI / 2)
  }

  return {
    selectedId,
    selectedNode,
    hoveredId,
    selectNode,
    deleteSelected,
    rotateSelected,
  }
}
