import { useCallback } from 'react'
import type { ThreeEvent } from '@react-three/fiber'
import useCircuitStore from '@/store/useCircuitStore'
import useInteractionStore from '@/store/useInteractionStore'
import { rayToPlane, findNearestConnectionPoint, buildWirePath, getConnectionPoints } from '@/utils/geometry'
import type { Vec3 } from '@/types'

// ─────────────────────────────────────────────────────────────────────────────
// useWiring — plane-level pointer handlers
//
// Handles both:
//  1. Wire-tool mode: user clicked Wire button, now clicks component A → B
//  2. Legacy terminal-click wiring (still works)
// ─────────────────────────────────────────────────────────────────────────────

export interface WiringPlaneHandlers {
  onPointerMove: (e: ThreeEvent<PointerEvent>) => void
  onClick: (e: ThreeEvent<MouseEvent>) => void
}

export function useWiring(): WiringPlaneHandlers {
  const onPointerMove = useCallback((e: ThreeEvent<PointerEvent>) => {
    const { mode, wiring, updateWiringPreview } = useInteractionStore.getState()
    if (mode !== 'wiring') return
    if (!wiring) return

    const hit = rayToPlane(e.ray, 0.14)
    if (!hit) return

    const cursor: Vec3 = { x: hit.x, y: 0.14, z: hit.z }

    // Try to snap to nearest connection point
    const nodes = useCircuitStore.getState().nodes
    const snap = findNearestConnectionPoint(cursor, nodes, 1.4, wiring.fromNodeId)

    // If snapped, preview end = snap world position; else raw cursor
    const previewEnd = snap ? snap.worldPosition : cursor
    updateWiringPreview(previewEnd, snap)
  }, [])

  const onClick = useCallback((e: ThreeEvent<MouseEvent>) => {
    const { mode, wiring, cancelWiring } = useInteractionStore.getState()
    if (mode !== 'wiring') return
    e.stopPropagation()
    cancelWiring()
  }, [])

  return { onPointerMove, onClick }
}

// ─────────────────────────────────────────────────────────────────────────────
// useComponentWireInteraction
//
// Replaces useTerminalInteraction — now operates at the component level
// (large hitbox) rather than requiring precise terminal clicks.
//
// In wire-tool mode:
//   - First click on any component picks the NEAREST terminal on that component
//     as the wire start point.
//   - Second click on any other component auto-connects to its nearest terminal.
//
// Also re-exports useTerminalInteraction for backwards compatibility.
// ─────────────────────────────────────────────────────────────────────────────

export interface ComponentWireHandlers {
  onClick: (e: ThreeEvent<MouseEvent>) => void
  onPointerEnter: (e: ThreeEvent<PointerEvent>) => void
  onPointerLeave: (e: ThreeEvent<PointerEvent>) => void
}

export function useComponentWireInteraction(nodeId: string): ComponentWireHandlers {
  const addWire = useCircuitStore((s) => s.addWire)

  const onClick = useCallback(
    (e: ThreeEvent<MouseEvent>) => {
      const store = useInteractionStore.getState()

      // Only handle in wire-tool or wiring mode
      if (!store.wireTool && store.mode !== 'wiring') return

      e.stopPropagation()

      if (store.mode === 'wiring') {
        const { wiring, cancelWiring } = store
        if (!wiring) { cancelWiring(); return }

        // Prevent self-connections
        if (wiring.fromNodeId === nodeId) {
          cancelWiring()
          return
        }

        // Find the best terminal on this target component
        const nodes = useCircuitStore.getState().nodes
        const targetNode = nodes.find(n => n.id === nodeId)
        if (!targetNode) { cancelWiring(); return }

        // Snap to the nearest terminal on target component relative to the
        // preview end position (or fromPosition as fallback)
        const refPoint = wiring.previewEnd ?? wiring.fromPosition
        const targetPts = getConnectionPoints(targetNode)
        if (targetPts.length === 0) { cancelWiring(); return }

        // Pick closest terminal on target
        let bestPt = targetPts[0]
        let bestDist = Infinity
        for (const pt of targetPts) {
          const dx = pt.worldPosition.x - refPoint.x
          const dz = pt.worldPosition.z - refPoint.z
          const d = Math.sqrt(dx * dx + dz * dz)
          if (d < bestDist) { bestDist = d; bestPt = pt }
        }

        const from = wiring.fromPosition
        const to = bestPt.worldPosition
        const points = buildWirePath(from, to)

        addWire({
          from: wiring.fromNodeId,
          to: nodeId,
          points,
        })
        cancelWiring()
        return
      }

      // Wire-tool mode, no active wiring session yet — start from this component
      if (store.wireTool && store.mode === 'idle') {
        const nodes = useCircuitStore.getState().nodes
        const node = nodes.find(n => n.id === nodeId)
        if (!node) return

        // Start from the first terminal (user can refine later)
        const pts = getConnectionPoints(node)
        if (pts.length === 0) return

        // Pick the closest terminal to the click ray intersection with the plane
        // (We use the component center as approximation)
        const startPt = pts[0]

        store.beginWiring(nodeId, startPt.terminal, startPt.worldPosition)
      }
    },
    [nodeId, addWire]
  )

  const onPointerEnter = useCallback((e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation()
    const store = useInteractionStore.getState()
    if (store.wireTool || store.mode === 'wiring') {
      store.setWireHovered(nodeId)
      document.body.style.cursor = 'crosshair'
    }
  }, [nodeId])

  const onPointerLeave = useCallback((_e: ThreeEvent<PointerEvent>) => {
    const store = useInteractionStore.getState()
    if (store.wireTool || store.mode === 'wiring') {
      store.setWireHovered(null)
      document.body.style.cursor = store.mode === 'wiring' ? 'crosshair' : ''
    }
  }, [])

  return { onClick, onPointerEnter, onPointerLeave }
}

// ─────────────────────────────────────────────────────────────────────────────
// useTerminalInteraction — legacy terminal-level interaction (kept for compat)
// ─────────────────────────────────────────────────────────────────────────────

export interface TerminalHandlers {
  onClick: (e: ThreeEvent<MouseEvent>) => void
  onPointerEnter: (e: ThreeEvent<PointerEvent>) => void
  onPointerLeave: (e: ThreeEvent<PointerEvent>) => void
}

export function useTerminalInteraction(
  nodeId: string,
  terminal: 'positive' | 'negative',
  worldPosition: Vec3
): TerminalHandlers {
  const addWire = useCircuitStore((s) => s.addWire)

  const onClick = useCallback(
    (e: ThreeEvent<MouseEvent>) => {
      e.stopPropagation()
      const store = useInteractionStore.getState()

      if (store.mode === 'dragging' || store.mode === 'placing') return

      if (store.mode === 'wiring') {
        const { wiring, cancelWiring } = store
        if (!wiring) { cancelWiring(); return }

        if (wiring.fromNodeId === nodeId && wiring.fromTerminal === terminal) {
          cancelWiring()
          return
        }

        const from = wiring.fromPosition
        const to = worldPosition
        const points = buildWirePath(from, to)

        addWire({
          from: wiring.fromNodeId,
          to: nodeId,
          points,
        })
        cancelWiring()
        return
      }

      // Start wiring from this terminal (legacy path)
      store.beginWiring(nodeId, terminal, worldPosition)
    },
    [nodeId, terminal, worldPosition, addWire]
  )

  const onPointerEnter = useCallback((e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation()
    document.body.style.cursor = 'crosshair'
  }, [])

  const onPointerLeave = useCallback((_e: ThreeEvent<PointerEvent>) => {
    const { mode } = useInteractionStore.getState()
    if (mode !== 'wiring') {
      document.body.style.cursor = ''
    }
  }, [])

  return { onClick, onPointerEnter, onPointerLeave }
}
