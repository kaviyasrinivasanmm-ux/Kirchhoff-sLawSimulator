import { useCallback } from 'react'
import { useFrame } from '@react-three/fiber'
import type { ThreeEvent } from '@react-three/fiber'
import * as THREE from 'three'
import useCircuitStore from '@/store/useCircuitStore'
import useInteractionStore from '@/store/useInteractionStore'
import { rayToPlane, snapToGrid } from '@/utils/geometry'

// ─────────────────────────────────────────────────────────────────────────────
// useDragHandler
//
// Attach the returned handlers to the invisible InteractionPlane that
// fills the scene. The plane receives pointermove / pointerup events
// even when the cursor leaves the original mesh (because pointer capture
// is set on pointerdown in useComponentInteraction).
//
// During a drag we update the store's node position every frame from
// useFrame (not from React event handlers) so we never trigger a React
// re-render for each pointer move — only when the pointer is up and the
// move commits.
// ─────────────────────────────────────────────────────────────────────────────

// Module-level mutable scratch: updated on pointer move, read in useFrame
const _live = { x: 0, z: 0, active: false }

export interface DragPlaneHandlers {
  onPointerMove: (e: ThreeEvent<PointerEvent>) => void
  onPointerUp: (e: ThreeEvent<PointerEvent>) => void
}

export function useDragHandler(): DragPlaneHandlers {
  const moveNode = useCircuitStore((s) => s.moveNode)
  const endDrag = useInteractionStore((s) => s.endDrag)
  const snapGrid = useInteractionStore((s) => s.snapGrid)

  // On every frame, if a drag is active push the live position to the store.
  // This is the only place where moveNode is called during a drag so the store
  // update rate is bounded to one per frame rather than one per DOM event.
  useFrame(() => {
    if (!_live.active) return
    const drag = useInteractionStore.getState().drag
    if (!drag) return

    const snappedX = snapToGrid(_live.x - drag.offsetX, snapGrid)
    const snappedZ = snapToGrid(_live.z - drag.offsetZ, snapGrid)
    moveNode(drag.nodeId, snappedX, snappedZ)
  })

  const onPointerMove = useCallback(
    (e: ThreeEvent<PointerEvent>) => {
      const drag = useInteractionStore.getState().drag
      if (!drag) return

      const hit = rayToPlane(e.ray, 0.14)
      if (!hit) return

      _live.x = hit.x
      _live.z = hit.z
      _live.active = true
    },
    []
  )

  const onPointerUp = useCallback(
    (e: ThreeEvent<PointerEvent>) => {
      const drag = useInteractionStore.getState().drag
      if (!drag) return

      // Final snap commit
      const hit = rayToPlane(e.ray, 0.14)
      if (hit) {
        const snappedX = snapToGrid(hit.x - drag.offsetX, snapGrid)
        const snappedZ = snapToGrid(hit.z - drag.offsetZ, snapGrid)
        moveNode(drag.nodeId, snappedX, snappedZ)
      }

      _live.active = false
      endDrag()
      document.body.style.cursor = ''

      // Release pointer capture
      try {
        ;(e.nativeEvent.target as HTMLElement).releasePointerCapture(
          e.nativeEvent.pointerId
        )
      } catch (_) {
        // ignore — may already be released
      }
    },
    [moveNode, endDrag, snapGrid]
  )

  return { onPointerMove, onPointerUp }
}

// Exported for InteractionPlane to call directly (needed before hook is called)
export function getLivePos(): THREE.Vector2 {
  return new THREE.Vector2(_live.x, _live.z)
}
