import { useCallback } from 'react'
import type { ThreeEvent } from '@react-three/fiber'
import useCircuitStore from '@/store/useCircuitStore'
import useInteractionStore from '@/store/useInteractionStore'
import { rayToPlane } from '@/utils/geometry'

// ─────────────────────────────────────────────────────────────────────────────
// useComponentInteraction
//
// Returns R3F event handlers to attach to the <group> of any circuit component.
// Wire-tool clicks are now handled here in addition to normal select/drag.
// ─────────────────────────────────────────────────────────────────────────────

export interface ComponentHandlers {
  onClick: (e: ThreeEvent<MouseEvent>) => void
  onPointerEnter: (e: ThreeEvent<PointerEvent>) => void
  onPointerLeave: (e: ThreeEvent<PointerEvent>) => void
  onPointerDown: (e: ThreeEvent<PointerEvent>) => void
}

export function useComponentInteraction(nodeId: string): ComponentHandlers {
  const selectNode = useCircuitStore((s) => s.selectNode)
  const selectedId = useCircuitStore((s) => s.selectedId)
  const setHovered = useInteractionStore((s) => s.setHovered)
  const beginDrag = useInteractionStore((s) => s.beginDrag)

  const onClick = useCallback(
    (e: ThreeEvent<MouseEvent>) => {
      e.stopPropagation()
      const store = useInteractionStore.getState()

      // Wire-tool clicks are handled by useComponentWireInteraction — skip here
      if (store.wireTool || store.mode === 'wiring') return

      // Toggle off if clicking already-selected
      selectNode(selectedId === nodeId ? null : nodeId)
    },
    [nodeId, selectedId, selectNode]
  )

  const onPointerEnter = useCallback(
    (e: ThreeEvent<PointerEvent>) => {
      e.stopPropagation()
      const store = useInteractionStore.getState()

      // In wire-tool mode, show crosshair glow feedback
      if (store.wireTool || store.mode === 'wiring') {
        store.setWireHovered(nodeId)
        document.body.style.cursor = 'crosshair'
        return
      }

      if (store.mode === 'idle' || store.mode === 'dragging') {
        setHovered(nodeId)
        document.body.style.cursor = 'grab'
      }
    },
    [nodeId, setHovered]
  )

  const onPointerLeave = useCallback(
    (_e: ThreeEvent<PointerEvent>) => {
      const store = useInteractionStore.getState()
      if (store.wireTool || store.mode === 'wiring') {
        store.setWireHovered(null)
        document.body.style.cursor = store.mode === 'wiring' ? 'crosshair' : ''
        return
      }
      setHovered(null)
      document.body.style.cursor = ''
    },
    [setHovered]
  )

  const onPointerDown = useCallback(
    (e: ThreeEvent<PointerEvent>) => {
      if (e.nativeEvent.button !== 0) return
      const store = useInteractionStore.getState()

      // In wire-tool mode, don't drag — wire clicks are handled by onClick
      if (store.wireTool || store.mode === 'wiring') return
      if (store.mode !== 'idle') return

      e.stopPropagation()
      ;(e.nativeEvent.target as HTMLElement).setPointerCapture(e.nativeEvent.pointerId)

      const hit = rayToPlane(e.ray, 0.14)
      if (!hit) return

      selectNode(nodeId)

      const node = useCircuitStore.getState().nodes.find((n) => n.id === nodeId)
      if (!node) return

      beginDrag(
        nodeId,
        hit.x - node.position.x,
        hit.z - node.position.z
      )

      document.body.style.cursor = 'grabbing'
    },
    [nodeId, selectNode, beginDrag]
  )

  return { onClick, onPointerEnter, onPointerLeave, onPointerDown }
}
