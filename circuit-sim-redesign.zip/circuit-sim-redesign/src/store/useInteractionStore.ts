import { create } from 'zustand'
import { subscribeWithSelector } from 'zustand/middleware'
import type { InteractionMode, DragState, PlacementGhost, ComponentType, Vec3, ConnectionPoint } from '@/types'

export interface WiringState {
  // First click: what did user click on
  fromNodeId: string
  fromTerminal: 'positive' | 'negative'
  fromPosition: Vec3
  // Live preview end (updated on pointer move, auto-snapped)
  previewEnd: Vec3 | null
  // The snapped-to connection point under cursor (if any)
  snapTarget: ConnectionPoint | null
}

interface InteractionStore {
  mode: InteractionMode
  hoveredId: string | null
  drag: DragState | null
  ghost: PlacementGhost | null
  activeTool: ComponentType | null
  snapGrid: number
  wiring: WiringState | null

  // Wire-tool mode: user has pressed the wire button, awaiting first click
  wireTool: boolean

  // Which component is being hovered during wire-tool mode (for glow feedback)
  wireHoveredNodeId: string | null

  setMode: (mode: InteractionMode) => void
  setHovered: (id: string | null) => void
  beginDrag: (nodeId: string, offsetX: number, offsetZ: number) => void
  endDrag: () => void
  setActiveTool: (type: ComponentType | null) => void
  updateGhost: (position: Vec3, snapped: boolean) => void
  clearGhost: () => void
  setSnapGrid: (size: number) => void

  // Wire tool
  enableWireTool: () => void
  disableWireTool: () => void

  // Wiring session (started after first click in wire-tool mode)
  beginWiring: (fromNodeId: string, fromTerminal: 'positive' | 'negative', fromPosition: Vec3) => void
  updateWiringPreview: (end: Vec3, snapTarget: ConnectionPoint | null) => void
  cancelWiring: () => void

  // Hover feedback in wire-tool mode
  setWireHovered: (id: string | null) => void
}

const useInteractionStore = create<InteractionStore>()(
  subscribeWithSelector((set) => ({
    mode: 'idle',
    hoveredId: null,
    drag: null,
    ghost: null,
    activeTool: null,
    snapGrid: 0.5,
    wiring: null,
    wireTool: false,
    wireHoveredNodeId: null,

    setMode: (mode) => set({ mode }),

    setHovered: (id) => set({ hoveredId: id }),

    beginDrag: (nodeId, offsetX, offsetZ) =>
      set({
        mode: 'dragging',
        drag: { nodeId, offsetX, offsetZ },
      }),

    endDrag: () =>
      set((s) => ({
        mode: s.activeTool ? 'placing' : (s.wireTool ? 'idle' : 'idle'),
        drag: null,
      })),

    setActiveTool: (type) =>
      set((s) => ({
        activeTool: type,
        mode: type ? 'placing' : 'idle',
        wireTool: false,
        ghost: type
          ? (s.ghost ?? {
              type,
              position: { x: 0, y: 0.14, z: 0 },
              rotation: { x: 0, y: 0, z: Math.PI / 2 },
              snapped: false,
            })
          : null,
      })),

    updateGhost: (position, snapped) =>
      set((s) => ({
        ghost: s.ghost
          ? { ...s.ghost, position, snapped }
          : null,
      })),

    clearGhost: () =>
      set({ ghost: null, activeTool: null, mode: 'idle' }),

    setSnapGrid: (size) => set({ snapGrid: size }),

    // ── Wire tool ────────────────────────────────────────────────────────────

    enableWireTool: () =>
      set({
        wireTool: true,
        activeTool: null,
        ghost: null,
        mode: 'idle',   // not 'wiring' yet — waiting for first click
        wiring: null,
      }),

    disableWireTool: () =>
      set({
        wireTool: false,
        wiring: null,
        wireHoveredNodeId: null,
        mode: 'idle',
      }),

    // ── Wiring session ───────────────────────────────────────────────────────

    beginWiring: (fromNodeId, fromTerminal, fromPosition) =>
      set({
        mode: 'wiring',
        wiring: { fromNodeId, fromTerminal, fromPosition, previewEnd: null, snapTarget: null },
        activeTool: null,
        ghost: null,
      }),

    updateWiringPreview: (end, snapTarget) =>
      set((s) => ({
        wiring: s.wiring
          ? { ...s.wiring, previewEnd: end, snapTarget }
          : null,
      })),

    cancelWiring: () =>
      set((s) => ({
        mode: 'idle',
        wiring: null,
        // Keep wireTool active so user can immediately try again
        wireHoveredNodeId: null,
      })),

    setWireHovered: (id) => set({ wireHoveredNodeId: id }),
  }))
)

export default useInteractionStore
