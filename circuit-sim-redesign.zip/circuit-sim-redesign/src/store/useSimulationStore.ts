import { create } from 'zustand'
import { subscribeWithSelector } from 'zustand/middleware'
import { solveCircuit } from '@/physics/solver'
import type { SimulationResult } from '@/physics/types'
import useCircuitStore from './useCircuitStore'

interface SimulationStore {
  result: SimulationResult | null
  tickCount: number
  running: boolean
  intervalMs: number
  startSimulation: () => void
  stopSimulation: () => void
  stepOnce: () => void
  setIntervalMs: (ms: number) => void
}

let _timerId: ReturnType<typeof setInterval> | null = null

const useSimulationStore = create<SimulationStore>()(
  subscribeWithSelector((set, get) => ({
    result: null,
    tickCount: 0,
    running: false,
    intervalMs: 500,

    startSimulation: () => {
      if (get().running) return
      set({ running: true })
      useCircuitStore.getState().setSimulating(true)
      const tick = () => {
        const { nodes, wires } = useCircuitStore.getState()
        const result = solveCircuit(nodes, wires)
        set((s) => ({ result, tickCount: s.tickCount + 1 }))
      }
      tick()
      _timerId = setInterval(tick, get().intervalMs)
    },

    stopSimulation: () => {
      if (_timerId !== null) { clearInterval(_timerId); _timerId = null }
      set({ running: false })
      useCircuitStore.getState().setSimulating(false)
    },

    stepOnce: () => {
      const { nodes, wires } = useCircuitStore.getState()
      const result = solveCircuit(nodes, wires)
      set((s) => ({ result, tickCount: s.tickCount + 1 }))
    },

    setIntervalMs: (ms) => {
      set({ intervalMs: ms })
      const { running, startSimulation, stopSimulation } = get()
      if (running) { stopSimulation(); startSimulation() }
    },
  }))
)

export default useSimulationStore
