import { create } from 'zustand'
import { subscribeWithSelector } from 'zustand/middleware'
import type { CircuitNode, Wire } from '@/types'
import { generateId } from '@/utils/ids'

// ─────────────────────────────────────────────────────────────────────────────
// Circuit store — persistent scene data
//
// Owns: nodes[], wires[], selectedId, simulating
// Does NOT own ephemeral UI state (drag position, hover, ghost) — see
// useInteractionStore for that.
// ─────────────────────────────────────────────────────────────────────────────

interface CircuitStore {
  // ── State ──────────────────────────────────────────────────
  nodes: CircuitNode[]
  wires: Wire[]
  selectedId: string | null
  simulating: boolean

  // ── Node operations ────────────────────────────────────────
  addNode: (node: Omit<CircuitNode, 'id'>) => string
  removeNode: (id: string) => void
  moveNode: (id: string, x: number, z: number) => void
  rotateNode: (id: string, deltaY: number) => void
  updateNodeProperties: (id: string, props: Record<string, number | string>) => void

  // ── Selection ──────────────────────────────────────────────
  selectNode: (id: string | null) => void
  deleteSelected: () => void

  // ── Wire operations ────────────────────────────────────────
  addWire: (wire: Omit<Wire, 'id'>) => string
  removeWire: (id: string) => void

  // ── Scene ──────────────────────────────────────────────────
  setSimulating: (value: boolean) => void
  reset: () => void
}

// ─── Initial demo nodes ──────────────────────────────────────────────────────
// Pre-populate the scene so there's something to interact with immediately.
const DEMO_NODES: CircuitNode[] = [
  {
    id: 'demo_battery_1',
    type: 'voltage-source',
    position: { x: -2.5, y: 0.14, z: 0 },
    rotation: { x: 0, y: 0, z: Math.PI / 2 },
    properties: { voltage: '9V', chargeLevel: 0.82 },
  },
  {
    id: 'demo_battery_2',
    type: 'voltage-source',
    position: { x: -2.5, y: 0.14, z: 2 },
    rotation: { x: 0, y: 0, z: Math.PI / 2 },
    properties: { voltage: '1.5V', chargeLevel: 0.35 },
  },
  {
    id: 'demo_resistor_1',
    type: 'resistor',
    position: { x: 0.5, y: 0.14, z: -1.5 },
    rotation: { x: 0, y: 0, z: Math.PI / 2 },
    properties: { value: '10kΩ' },
  },
  {
    id: 'demo_resistor_2',
    type: 'resistor',
    position: { x: 0.5, y: 0.14, z: -0.2 },
    rotation: { x: 0, y: 0, z: Math.PI / 2 },
    properties: { value: '4.7kΩ' },
  },
  {
    id: 'demo_resistor_3',
    type: 'resistor',
    position: { x: 0.5, y: 0.14, z: 1.1 },
    rotation: { x: 0, y: 0, z: Math.PI / 2 },
    properties: { value: '220Ω' },
  },
  {
    id: 'demo_resistor_4',
    type: 'resistor',
    position: { x: 0.5, y: 0.14, z: 2.4 },
    rotation: { x: 0, y: 0, z: Math.PI / 2 },
    properties: { value: '1MΩ' },
  },
]

const INITIAL_STATE = {
  nodes: DEMO_NODES,
  wires: [] as Wire[],
  selectedId: null as string | null,
  simulating: false,
}

const useCircuitStore = create<CircuitStore>()(
  subscribeWithSelector((set, get) => ({
    ...INITIAL_STATE,

    // ── Node operations ────────────────────────────────────
    addNode: (partial) => {
      const id = generateId(partial.type)
      const node: CircuitNode = { ...partial, id }
      set((s) => ({ nodes: [...s.nodes, node] }))
      return id
    },

    removeNode: (id) =>
      set((s) => ({
        nodes: s.nodes.filter((n) => n.id !== id),
        wires: s.wires.filter((w) => w.from !== id && w.to !== id),
        selectedId: s.selectedId === id ? null : s.selectedId,
      })),

    moveNode: (id, x, z) =>
      set((s) => ({
        nodes: s.nodes.map((n) =>
          n.id === id ? { ...n, position: { ...n.position, x, z } } : n
        ),
      })),

    rotateNode: (id, deltaY) =>
      set((s) => ({
        nodes: s.nodes.map((n) =>
          n.id === id
            ? { ...n, rotation: { ...n.rotation, y: n.rotation.y + deltaY } }
            : n
        ),
      })),

    updateNodeProperties: (id, props) =>
      set((s) => ({
        nodes: s.nodes.map((n) =>
          n.id === id ? { ...n, properties: { ...n.properties, ...props } } : n
        ),
      })),

    // ── Selection ──────────────────────────────────────────
    selectNode: (id) => set({ selectedId: id }),

    deleteSelected: () => {
      const { selectedId, removeNode } = get()
      if (selectedId) removeNode(selectedId)
    },

    // ── Wire operations ────────────────────────────────────
    addWire: (partial) => {
      const id = generateId('wire')
      const wire: Wire = { ...partial, id }
      set((s) => ({ wires: [...s.wires, wire] }))
      return id
    },

    removeWire: (id) =>
      set((s) => ({ wires: s.wires.filter((w) => w.id !== id) })),

    // ── Scene ──────────────────────────────────────────────
    setSimulating: (simulating) => set({ simulating }),

    reset: () => set(INITIAL_STATE),
  }))
)

export default useCircuitStore
