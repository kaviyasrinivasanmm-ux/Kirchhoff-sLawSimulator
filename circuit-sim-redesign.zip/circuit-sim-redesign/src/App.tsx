import { Suspense, useState, useEffect } from 'react'
import { Canvas } from '@react-three/fiber'
import { useKeyboard } from '@/hooks/useKeyboard'
import SceneRoot from '@/components/scene/SceneRoot'
import Toolbar from '@/components/ui/Toolbar'
import PropertiesPanel from '@/components/ui/PropertiesPanel'
import StatusBar from '@/components/ui/StatusBar'
import LoadingOverlay from '@/components/ui/LoadingOverlay'
import useCircuitStore from '@/store/useCircuitStore'
import useInteractionStore from '@/store/useInteractionStore'

// ── First-time tutorial overlay ────────────────────────────────────────────
function FirstTimeHint() {
  const [dismissed, setDismissed] = useState(false)
  const nodeCount = useCircuitStore((s) => s.nodes.length)
  const wireCount = useCircuitStore((s) => s.wires.length)
  const wireTool = useInteractionStore((s) => s.wireTool)
  const mode = useInteractionStore((s) => s.mode)

  // Auto-dismiss once user starts wiring
  useEffect(() => {
    if (wireTool || mode === 'wiring' || wireCount > 0) setDismissed(true)
  }, [wireTool, mode, wireCount])

  if (dismissed || nodeCount === 0) return null

  return (
    <div
      className="fade-in"
      style={{
        position: 'absolute',
        bottom: 48,
        left: '50%',
        transform: 'translateX(-50%)',
        background: 'rgba(11,15,28,0.92)',
        backdropFilter: 'blur(20px)',
        border: '1px solid rgba(0,229,255,0.2)',
        borderRadius: 14,
        padding: '14px 20px',
        display: 'flex',
        alignItems: 'center',
        gap: 16,
        boxShadow: '0 4px 40px rgba(0,0,0,0.5), 0 0 30px rgba(0,229,255,0.05)',
        zIndex: 100,
        minWidth: 360,
        maxWidth: 500,
        pointerEvents: 'none',
      }}
    >
      <div style={{
        width: 36,
        height: 36,
        borderRadius: 10,
        background: 'rgba(0,229,255,0.1)',
        border: '1px solid rgba(0,229,255,0.25)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: 18,
        flexShrink: 0,
      }}>💡</div>
      <div>
        <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--color-text)', marginBottom: 3 }}>
          Ready to connect components?
        </div>
        <div style={{ fontSize: 11, color: 'var(--color-text-muted)', lineHeight: 1.5 }}>
          Click <span style={{ color: 'var(--color-accent)', fontWeight: 600 }}>Wire Tool</span> in the toolbar,
          then click two components to draw a wire between them.
        </div>
      </div>
    </div>
  )
}

function AppContent() {
  useKeyboard()
  return (
    <div className="flex flex-col w-full h-full" style={{ background: 'var(--color-bg)' }}>
      <Toolbar />
      <div className="flex flex-1 overflow-hidden" style={{ position: 'relative' }}>
        <div className="flex-1 relative">
          <Suspense fallback={<LoadingOverlay />}>
            <Canvas
              shadows
              gl={{
                antialias: true,
                alpha: false,
                powerPreference: 'high-performance',
                toneMapping: 3, // ACESFilmicToneMapping
                toneMappingExposure: 1.1,
              }}
              style={{ background: '#06080f' }}
              dpr={[1, 2]}
              eventPrefix="client"
            >
              <SceneRoot />
            </Canvas>
          </Suspense>
          <FirstTimeHint />
        </div>
        <PropertiesPanel />
      </div>
      <StatusBar />
    </div>
  )
}

export default function App() {
  return <AppContent />
}
