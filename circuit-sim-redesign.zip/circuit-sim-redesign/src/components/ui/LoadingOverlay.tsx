export default function LoadingOverlay() {
  return (
    <div
      style={{
        position: 'absolute',
        inset: 0,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        background: 'var(--color-bg)',
        gap: 16,
        zIndex: 10,
      }}
    >
      {/* Animated logo mark */}
      <div style={{
        width: 48,
        height: 48,
        borderRadius: 14,
        background: 'linear-gradient(135deg, rgba(0,229,255,0.15), rgba(0,255,135,0.08))',
        border: '1px solid rgba(0,229,255,0.25)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: 24,
        animation: 'pulse-dot 1.4s ease-in-out infinite',
      }}>⚛</div>

      <div style={{ textAlign: 'center' }}>
        <div style={{
          fontSize: 14,
          fontWeight: 700,
          background: 'linear-gradient(90deg, var(--color-accent), var(--color-green))',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
          letterSpacing: '0.05em',
          marginBottom: 4,
        }}>CircuitSim</div>
        <div style={{ fontSize: 11, color: 'var(--color-text-muted)', fontFamily: 'monospace' }}>
          Loading 3D scene…
        </div>
      </div>

      {/* Progress bar */}
      <div style={{
        width: 120,
        height: 2,
        background: 'var(--color-border)',
        borderRadius: 1,
        overflow: 'hidden',
      }}>
        <div style={{
          height: '100%',
          width: '40%',
          background: 'linear-gradient(90deg, var(--color-accent), var(--color-green))',
          borderRadius: 1,
          animation: 'slide-loading 1.2s ease-in-out infinite',
        }}/>
      </div>

      <style>{`
        @keyframes slide-loading {
          0% { transform: translateX(-200%); }
          100% { transform: translateX(400%); }
        }
      `}</style>
    </div>
  )
}
