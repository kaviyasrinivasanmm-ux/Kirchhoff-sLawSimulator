import useCircuitStore from '@/store/useCircuitStore'
import useInteractionStore from '@/store/useInteractionStore'
import useSimulationStore from '@/store/useSimulationStore'

export default function StatusBar() {
  const nodeCount = useCircuitStore((s) => s.nodes.length)
  const wireCount = useCircuitStore((s) => s.wires.length)
  const mode = useInteractionStore((s) => s.mode)
  const snapGrid = useInteractionStore((s) => s.snapGrid)
  const wiring = useInteractionStore((s) => s.wiring)
  const wireTool = useInteractionStore((s) => s.wireTool)
  const wireHoveredNodeId = useInteractionStore((s) => s.wireHoveredNodeId)
  const running = useSimulationStore((s) => s.running)
  const tickCount = useSimulationStore((s) => s.tickCount)

  const shortId = (id: string) => id.split('_').slice(0, 2).join('_')

  return (
    <div
      className="flex items-center gap-4 px-4 select-none shrink-0"
      style={{
        height: '28px',
        background: 'var(--color-surface)',
        borderTop: '1px solid var(--color-border)',
        boxShadow: '0 -1px 6px rgba(0,0,0,0.3)',
        fontSize: '11px',
        color: 'var(--color-text-muted)',
        fontFamily: 'monospace',
      }}
    >
      {/* Sim status dot */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
        <span className={running ? 'pulse' : ''} style={{
          width: 6,
          height: 6,
          borderRadius: '50%',
          background: running ? 'var(--color-green)' : 'var(--color-text-dim)',
          display: 'inline-block',
        }}/>
        <span style={{ color: running ? 'var(--color-green)' : 'var(--color-text-muted)' }}>
          {running ? `Simulating · tick #${tickCount}` : 'Ready'}
        </span>
      </div>

      <span style={{ color: 'var(--color-border)', userSelect: 'none' }}>│</span>

      <span>
        <span style={{ color: 'var(--color-accent)', fontWeight: 700 }}>{nodeCount}</span>
        {' '}components
      </span>
      <span>
        <span style={{ color: 'var(--color-amber)', fontWeight: 700 }}>{wireCount}</span>
        {' '}wires
      </span>

      {snapGrid > 0 && (
        <>
          <span style={{ color: 'var(--color-border)', userSelect: 'none' }}>│</span>
          <span style={{ color: 'var(--color-green)' }}>⊞ Snap {snapGrid}u</span>
        </>
      )}

      {/* Wire tool status */}
      {(wireTool || mode === 'wiring') && (
        <>
          <span style={{ color: 'var(--color-border)', userSelect: 'none' }}>│</span>
          <span style={{
            color: mode === 'wiring' ? 'var(--color-amber)' : 'var(--color-accent)',
            fontWeight: 600,
          }}>
            {mode === 'wiring' && wiring ? (
              <>
                〜 From <b>{shortId(wiring.fromNodeId)}</b>
                {wireHoveredNodeId
                  ? <> → click <span style={{ color: 'var(--color-green)' }}>{shortId(wireHoveredNodeId)}</span> to connect</>
                  : <> · hover a component</>
                }
              </>
            ) : (
              <>
                〜 Wire Tool active
                {wireHoveredNodeId
                  ? <> · click <span style={{ color: 'var(--color-green)' }}>{shortId(wireHoveredNodeId)}</span></>
                  : <> · click a component to start</>
                }
              </>
            )}
          </span>
        </>
      )}

      <div style={{ flex: 1 }} />

      {/* Keyboard hints */}
      <span>
        Del · Esc · W · R · B
      </span>
    </div>
  )
}
