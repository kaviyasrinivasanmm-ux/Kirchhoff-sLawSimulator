import useCircuitStore from '@/store/useCircuitStore'
import useInteractionStore from '@/store/useInteractionStore'
import useSimulationStore from '@/store/useSimulationStore'
import type { ComponentType } from '@/types'

interface ToolDef { label: string; type: ComponentType; icon: string; shortcut: string }

const TOOLS: ToolDef[] = [
  { label: 'Resistor',       type: 'resistor',       icon: '⟨Ω⟩', shortcut: 'R' },
  { label: 'Capacitor',      type: 'capacitor',      icon: '⊣⊢',   shortcut: 'C' },
  { label: 'Inductor',       type: 'inductor',       icon: '∿',    shortcut: 'L' },
  { label: 'Battery',        type: 'voltage-source', icon: '⚡',   shortcut: 'B' },
]

export default function Toolbar() {
  const reset = useCircuitStore((s) => s.reset)
  const activeTool = useInteractionStore((s) => s.activeTool)
  const setActiveTool = useInteractionStore((s) => s.setActiveTool)
  const snapGrid = useInteractionStore((s) => s.snapGrid)
  const setSnapGrid = useInteractionStore((s) => s.setSnapGrid)
  const mode = useInteractionStore((s) => s.mode)
  const wireTool = useInteractionStore((s) => s.wireTool)
  const enableWireTool = useInteractionStore((s) => s.enableWireTool)
  const disableWireTool = useInteractionStore((s) => s.disableWireTool)
  const cancelWiring = useInteractionStore((s) => s.cancelWiring)

  const running = useSimulationStore((s) => s.running)
  const startSimulation = useSimulationStore((s) => s.startSimulation)
  const stopSimulation = useSimulationStore((s) => s.stopSimulation)
  const stepOnce = useSimulationStore((s) => s.stepOnce)

  const isWiringActive = wireTool || mode === 'wiring'

  const handleWireToolClick = () => {
    if (isWiringActive) {
      cancelWiring()
      disableWireTool()
    } else {
      setActiveTool(null)
      enableWireTool()
    }
  }

  return (
    <div
      className="flex items-center gap-1 px-3 select-none shrink-0"
      style={{
        height: '52px',
        background: 'var(--color-surface)',
        borderBottom: '1px solid var(--color-border)',
        boxShadow: '0 1px 12px rgba(0,0,0,0.4)',
      }}
    >
      {/* Logo */}
      <div className="flex items-center gap-2 mr-3">
        <div style={{
          width: 28,
          height: 28,
          borderRadius: 8,
          background: 'linear-gradient(135deg, rgba(0,229,255,0.15), rgba(0,255,135,0.08))',
          border: '1px solid rgba(0,229,255,0.25)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: 14,
        }}>⚛</div>
        <span style={{
          fontWeight: 700,
          fontSize: 13,
          letterSpacing: '0.05em',
          background: 'linear-gradient(90deg, var(--color-accent), var(--color-green))',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
        }}>
          CircuitSim
        </span>
      </div>

      {/* Divider */}
      <div style={{ width: 1, height: 24, background: 'var(--color-border)', margin: '0 6px' }} />

      {/* Component tools */}
      <div className="flex items-center gap-1">
        {TOOLS.map((tool) => {
          const active = activeTool === tool.type
          return (
            <button
              key={tool.type}
              onClick={() => {
                if (isWiringActive) { cancelWiring(); disableWireTool() }
                setActiveTool(active ? null : tool.type)
              }}
              title={`${tool.label} [${tool.shortcut}]`}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 6,
                padding: '5px 10px',
                borderRadius: 8,
                fontSize: 12,
                fontWeight: active ? 700 : 500,
                background: active
                  ? 'linear-gradient(135deg, rgba(0,229,255,0.18), rgba(0,229,255,0.08))'
                  : 'transparent',
                color: active ? 'var(--color-accent)' : 'var(--color-text-muted)',
                border: active
                  ? '1px solid rgba(0,229,255,0.35)'
                  : '1px solid transparent',
                boxShadow: active ? '0 0 12px rgba(0,229,255,0.15)' : 'none',
              }}
            >
              <span style={{ fontSize: 14 }}>{tool.icon}</span>
              <span>{tool.label}</span>
              <span style={{
                fontSize: 9,
                fontWeight: 600,
                opacity: 0.45,
                letterSpacing: '0.05em',
                background: 'rgba(255,255,255,0.07)',
                padding: '1px 4px',
                borderRadius: 3,
              }}>{tool.shortcut}</span>
            </button>
          )
        })}
      </div>

      {/* Divider */}
      <div style={{ width: 1, height: 24, background: 'var(--color-border)', margin: '0 6px' }} />

      {/* Wire Tool — the hero CTA */}
      <button
        onClick={handleWireToolClick}
        title={
          mode === 'wiring'
            ? 'Click a component to complete the wire  •  Esc or right-click to cancel'
            : wireTool
            ? 'Click any component to start a wire  •  Esc to cancel'
            : 'Wire Tool: connect components by clicking them in sequence'
        }
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 7,
          padding: '6px 14px',
          borderRadius: 8,
          fontSize: 12,
          fontWeight: 700,
          background: isWiringActive
            ? mode === 'wiring'
              ? 'linear-gradient(135deg, rgba(251,191,36,0.2), rgba(251,191,36,0.08))'
              : 'linear-gradient(135deg, rgba(0,229,255,0.2), rgba(0,229,255,0.08))'
            : 'linear-gradient(135deg, rgba(0,229,255,0.12), rgba(0,229,255,0.04))',
          color: isWiringActive
            ? mode === 'wiring' ? 'var(--color-amber)' : 'var(--color-accent)'
            : 'var(--color-accent)',
          border: isWiringActive
            ? `1px solid ${mode === 'wiring' ? 'rgba(251,191,36,0.5)' : 'rgba(0,229,255,0.5)'}`
            : '1px solid rgba(0,229,255,0.25)',
          boxShadow: isWiringActive
            ? `0 0 16px ${mode === 'wiring' ? 'rgba(251,191,36,0.2)' : 'rgba(0,229,255,0.2)'}`
            : '0 0 8px rgba(0,229,255,0.08)',
        }}
      >
        {/* Wire icon */}
        <svg width="16" height="12" viewBox="0 0 16 12" fill="none">
          <path d="M1 6 Q4 1 8 6 Q12 11 15 6" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" fill="none"/>
          <circle cx="1" cy="6" r="1.5" fill="currentColor"/>
          <circle cx="15" cy="6" r="1.5" fill="currentColor"/>
        </svg>
        {isWiringActive
          ? mode === 'wiring' ? '→ Click Target' : '◉ Click Source'
          : 'Wire Tool'}
        <span style={{
          fontSize: 9,
          fontWeight: 600,
          opacity: 0.5,
          background: 'rgba(255,255,255,0.07)',
          padding: '1px 4px',
          borderRadius: 3,
        }}>W</span>
        {isWiringActive && (
          <span style={{
            marginLeft: 2,
            fontSize: 11,
            opacity: 0.65,
            color: 'inherit',
          }}>✕</span>
        )}
      </button>

      {/* Wire tool status pill */}
      {isWiringActive && (
        <div className="fade-in flex items-center gap-2"
          style={{
            padding: '4px 10px',
            borderRadius: 20,
            background: mode === 'wiring' ? 'rgba(251,191,36,0.08)' : 'rgba(0,229,255,0.06)',
            border: `1px solid ${mode === 'wiring' ? 'rgba(251,191,36,0.2)' : 'rgba(0,229,255,0.15)'}`,
            fontSize: 11,
            fontWeight: 500,
            color: mode === 'wiring' ? 'var(--color-amber)' : 'var(--color-accent)',
          }}
        >
          <span className="pulse" style={{
            width: 6,
            height: 6,
            borderRadius: '50%',
            background: 'currentColor',
            display: 'inline-block',
            flexShrink: 0,
          }}/>
          {mode === 'wiring'
            ? 'Now click the destination component'
            : 'Click any component to begin a wire'}
        </div>
      )}

      <div style={{ flex: 1 }} />

      {/* Snap toggle */}
      <button
        onClick={() => {
          const c = [0.5, 0.25, 0]
          setSnapGrid(c[(c.indexOf(snapGrid) + 1) % c.length])
        }}
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 5,
          padding: '5px 10px',
          borderRadius: 8,
          fontSize: 11,
          fontWeight: 600,
          background: snapGrid > 0 ? 'rgba(0,255,135,0.08)' : 'transparent',
          color: snapGrid > 0 ? 'var(--color-green)' : 'var(--color-text-muted)',
          border: `1px solid ${snapGrid > 0 ? 'rgba(0,255,135,0.2)' : 'transparent'}`,
        }}
      >
        <span>⊞</span>
        <span>Snap {snapGrid > 0 ? `${snapGrid}u` : 'off'}</span>
      </button>

      <div style={{ width: 1, height: 24, background: 'var(--color-border)', margin: '0 6px' }} />

      {/* Sim controls */}
      <button
        onClick={stepOnce}
        style={{
          padding: '5px 10px',
          borderRadius: 8,
          fontSize: 11,
          fontWeight: 600,
          background: 'transparent',
          color: 'var(--color-text-muted)',
          border: '1px solid transparent',
        }}
      >⏭ Step</button>

      <button
        onClick={running ? stopSimulation : startSimulation}
        style={{
          padding: '6px 16px',
          borderRadius: 8,
          fontSize: 12,
          fontWeight: 700,
          background: running
            ? 'linear-gradient(135deg, rgba(255,77,109,0.25), rgba(255,77,109,0.1))'
            : 'linear-gradient(135deg, rgba(0,229,255,0.3), rgba(0,229,255,0.1))',
          color: running ? 'var(--color-red)' : 'var(--color-accent)',
          border: running ? '1px solid rgba(255,77,109,0.4)' : '1px solid rgba(0,229,255,0.4)',
          boxShadow: running ? '0 0 16px rgba(255,77,109,0.15)' : '0 0 12px rgba(0,229,255,0.12)',
        }}
      >
        {running ? '⏹ Stop' : '▶ Simulate'}
      </button>

      <button
        onClick={reset}
        style={{
          padding: '5px 10px',
          borderRadius: 8,
          fontSize: 11,
          fontWeight: 500,
          background: 'transparent',
          color: 'var(--color-text-muted)',
          border: '1px solid transparent',
          marginLeft: 2,
        }}
      >↺ Reset</button>
    </div>
  )
}
