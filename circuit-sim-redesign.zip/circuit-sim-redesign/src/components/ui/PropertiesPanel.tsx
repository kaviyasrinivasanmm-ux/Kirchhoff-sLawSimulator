import { useSelection } from '@/hooks/useSelection'
import useInteractionStore from '@/store/useInteractionStore'
import useCircuitStore from '@/store/useCircuitStore'
import useSimulationStore from '@/store/useSimulationStore'
import { formatVoltage, formatCurrent, formatPower } from '@/utils/units'

const MODE_META: Record<string, { color: string; label: string; icon: string }> = {
  idle:     { color: 'var(--color-accent)',  label: 'Ready',    icon: '○' },
  placing:  { color: 'var(--color-green)',   label: 'Placing',  icon: '＋' },
  dragging: { color: 'var(--color-amber)',   label: 'Moving',   icon: '↔' },
  wiring:   { color: 'var(--color-violet)',  label: 'Wiring',   icon: '〜' },
}

export default function PropertiesPanel() {
  const { selectedNode, deleteSelected, rotateSelected } = useSelection()
  const mode = useInteractionStore((s) => s.mode)
  const wireTool = useInteractionStore((s) => s.wireTool)
  const wiring = useInteractionStore((s) => s.wiring)
  const nodeCount = useCircuitStore((s) => s.nodes.length)
  const wireCount = useCircuitStore((s) => s.wires.length)
  const { result, running, tickCount } = useSimulationStore()

  const branch = selectedNode ? result?.branches.get(selectedNode.id) : null
  const modeMeta = MODE_META[mode] ?? MODE_META.idle
  const displayMode = (wireTool && mode === 'idle') ? { color: 'var(--color-accent)', label: 'Wire Tool', icon: '〜' } : modeMeta

  return (
    <div
      className="flex flex-col shrink-0"
      style={{
        width: '256px',
        background: 'var(--color-surface)',
        borderLeft: '1px solid var(--color-border)',
      }}
    >
      {/* Header */}
      <div
        className="flex items-center justify-between px-4 py-3 shrink-0"
        style={{ borderBottom: '1px solid var(--color-border)' }}
      >
        <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.1em', color: 'var(--color-text-muted)', textTransform: 'uppercase' }}>
          Inspector
        </span>
        {/* Mode badge */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: 5,
          padding: '3px 8px',
          borderRadius: 20,
          background: `${displayMode.color}14`,
          border: `1px solid ${displayMode.color}30`,
          fontSize: 11,
          fontWeight: 700,
          color: displayMode.color,
        }}>
          <span>{displayMode.icon}</span>
          <span>{displayMode.label}</span>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto" style={{ padding: 12, display: 'flex', flexDirection: 'column', gap: 10 }}>

        {/* Wire tool guide */}
        {(wireTool || mode === 'wiring') && (
          <div className="fade-in" style={{
            background: 'rgba(0,229,255,0.05)',
            border: '1px solid rgba(0,229,255,0.15)',
            borderRadius: 10,
            padding: '12px 14px',
          }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--color-accent)', marginBottom: 10, letterSpacing: '0.05em' }}>
              WIRING GUIDE
            </div>
            {[
              { step: '1', text: mode === 'wiring' ? '✓ Source selected' : 'Click source component', done: mode === 'wiring' },
              { step: '2', text: 'Click destination', done: false },
              { step: '3', text: 'Wire auto-connects', done: false },
            ].map(({ step, text, done }) => (
              <div key={step} style={{
                display: 'flex',
                alignItems: 'center',
                gap: 8,
                marginBottom: 7,
                opacity: done ? 1 : 0.6,
              }}>
                <span className="step-badge" style={{
                  background: done ? 'rgba(0,255,135,0.15)' : 'var(--color-accent-soft)',
                  borderColor: done ? 'rgba(0,255,135,0.35)' : 'rgba(0,229,255,0.2)',
                  color: done ? 'var(--color-green)' : 'var(--color-accent)',
                }}>{done ? '✓' : step}</span>
                <span style={{ fontSize: 12, color: done ? 'var(--color-green)' : 'var(--color-text)' }}>{text}</span>
              </div>
            ))}
            <div style={{ fontSize: 10, color: 'var(--color-text-muted)', marginTop: 8, paddingTop: 8, borderTop: '1px solid var(--color-border)' }}>
              Press <kbd style={{ background: 'var(--color-surface-high)', padding: '1px 5px', borderRadius: 3, fontFamily: 'monospace' }}>Esc</kbd> or right-click to cancel
            </div>
          </div>
        )}

        {/* No selection hint */}
        {!selectedNode && mode === 'idle' && !wireTool && (
          <div style={{
            padding: '14px',
            borderRadius: 10,
            background: 'var(--color-surface-high)',
            border: '1px solid var(--color-border)',
            fontSize: 12,
            color: 'var(--color-text-muted)',
            lineHeight: 1.6,
          }}>
            <div style={{ fontWeight: 700, color: 'var(--color-text)', marginBottom: 8, fontSize: 12 }}>
              How to use
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              <Hint icon="＋" text="Pick a component from toolbar" />
              <Hint icon="↔" text="Drag to place on the board" />
              <Hint icon="〜" text="Wire Tool to connect components" />
              <Hint icon="▶" text="Simulate to see current flow" />
            </div>
          </div>
        )}

        {/* Selected component */}
        {selectedNode && (
          <div className="fade-in" style={{
            borderRadius: 10,
            border: '1px solid var(--color-border)',
            overflow: 'hidden',
          }}>
            {/* Component header */}
            <div style={{
              padding: '10px 14px',
              background: 'var(--color-surface-high)',
              borderBottom: '1px solid var(--color-border)',
              display: 'flex',
              alignItems: 'center',
              gap: 8,
            }}>
              <div style={{
                width: 28,
                height: 28,
                borderRadius: 8,
                background: 'rgba(0,229,255,0.1)',
                border: '1px solid rgba(0,229,255,0.2)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: 14,
              }}>
                {selectedNode.type === 'resistor' ? '⟨Ω⟩' :
                 selectedNode.type === 'voltage-source' ? '⚡' : '⊣⊢'}
              </div>
              <div>
                <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--color-text)' }}>
                  {selectedNode.type === 'voltage-source' ? 'Battery' :
                   selectedNode.type.charAt(0).toUpperCase() + selectedNode.type.slice(1)}
                </div>
                <div style={{ fontSize: 10, color: 'var(--color-text-muted)', fontFamily: 'monospace' }}>
                  {selectedNode.id}
                </div>
              </div>
            </div>

            {/* Properties */}
            <div style={{ padding: 14, display: 'flex', flexDirection: 'column', gap: 10 }}>
              {Object.entries(selectedNode.properties).map(([k, v]) => (
                <div key={k}>
                  <div className="field-label" style={{ marginBottom: 4 }}>{k}</div>
                  <div style={{
                    padding: '6px 10px',
                    borderRadius: 6,
                    background: 'var(--color-surface-high)',
                    border: '1px solid var(--color-border)',
                    fontSize: 13,
                    fontFamily: 'monospace',
                    color: 'var(--color-text)',
                  }}>{String(v)}</div>
                </div>
              ))}

              {/* Sim result for this node */}
              {branch && (
                <div style={{
                  padding: '10px',
                  borderRadius: 8,
                  background: 'rgba(0,229,255,0.05)',
                  border: '1px solid rgba(0,229,255,0.12)',
                  marginTop: 4,
                }}>
                  <div style={{ fontSize: 10, fontWeight: 700, color: 'var(--color-accent)', marginBottom: 8, letterSpacing: '0.08em' }}>
                    LIVE READINGS
                  </div>
                  {branch.voltage !== undefined && (
                    <SimReading label="Voltage" value={formatVoltage(branch.voltage)} color="var(--color-amber)" />
                  )}
                  {branch.current !== undefined && (
                    <SimReading label="Current" value={formatCurrent(branch.current)} color="var(--color-green)" />
                  )}
                  {branch.voltage !== undefined && branch.current !== undefined && (
                    <SimReading label="Power" value={formatPower(branch.voltage * branch.current)} color="var(--color-violet)" />
                  )}
                </div>
              )}

              {/* Actions */}
              <div style={{ display: 'flex', gap: 6, marginTop: 4 }}>
                <button
                  onClick={rotateSelected}
                  style={{
                    flex: 1,
                    padding: '6px',
                    borderRadius: 7,
                    border: '1px solid var(--color-border)',
                    background: 'var(--color-surface-high)',
                    color: 'var(--color-text-muted)',
                    fontSize: 11,
                    fontWeight: 600,
                  }}
                >↻ Rotate</button>
                <button
                  onClick={deleteSelected}
                  style={{
                    flex: 1,
                    padding: '6px',
                    borderRadius: 7,
                    border: '1px solid rgba(255,77,109,0.2)',
                    background: 'rgba(255,77,109,0.06)',
                    color: 'var(--color-red)',
                    fontSize: 11,
                    fontWeight: 600,
                  }}
                >⌫ Delete</button>
              </div>
            </div>
          </div>
        )}

        {/* Simulation results summary */}
        {result && (
          <div className="fade-in" style={{
            borderRadius: 10,
            border: '1px solid var(--color-border)',
            overflow: 'hidden',
          }}>
            <div style={{
              padding: '8px 14px',
              background: 'var(--color-surface-high)',
              borderBottom: '1px solid var(--color-border)',
              display: 'flex',
              alignItems: 'center',
              gap: 8,
            }}>
              <span className={running ? 'pulse' : ''} style={{
                width: 7,
                height: 7,
                borderRadius: '50%',
                background: running ? 'var(--color-green)' : 'var(--color-text-muted)',
                display: 'inline-block',
              }}/>
              <span style={{ fontSize: 11, fontWeight: 700, color: running ? 'var(--color-green)' : 'var(--color-text-muted)', letterSpacing: '0.08em' }}>
                {running ? 'SIMULATING' : 'PAUSED'}
              </span>
              <span style={{ fontSize: 10, color: 'var(--color-text-muted)', marginLeft: 'auto', fontFamily: 'monospace' }}>
                tick #{tickCount}
              </span>
            </div>
            <div style={{ padding: '10px 14px', fontSize: 12, color: 'var(--color-text-muted)' }}>
              Select a component to see its live readings.
            </div>
          </div>
        )}

        {/* Scene stats */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
          gap: 8,
          marginTop: 'auto',
        }}>
          <StatCard label="Components" value={nodeCount} color="var(--color-accent)" />
          <StatCard label="Wires" value={wireCount} color="var(--color-amber)" />
        </div>

        {/* Keyboard shortcuts */}
        <div style={{
          borderRadius: 10,
          border: '1px solid var(--color-border)',
          padding: '10px 14px',
          background: 'var(--color-surface-high)',
        }}>
          <div style={{ fontSize: 10, fontWeight: 700, color: 'var(--color-text-muted)', marginBottom: 8, letterSpacing: '0.1em' }}>
            SHORTCUTS
          </div>
          {[
            ['Del', 'Delete selected'],
            ['Esc', 'Cancel / deselect'],
            ['R', 'Resistor'],
            ['B', 'Battery'],
            ['W', 'Wire Tool'],
            ['G', 'Toggle grid'],
          ].map(([key, label]) => (
            <div key={key} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 5 }}>
              <kbd style={{
                fontFamily: 'monospace',
                fontSize: 11,
                background: 'var(--color-border)',
                padding: '1px 6px',
                borderRadius: 4,
                color: 'var(--color-accent)',
                fontWeight: 700,
              }}>{key}</kbd>
              <span style={{ fontSize: 11, color: 'var(--color-text-muted)' }}>{label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

function Hint({ icon, text }: { icon: string; text: string }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <span style={{
        width: 22,
        height: 22,
        borderRadius: 6,
        background: 'rgba(0,229,255,0.06)',
        border: '1px solid rgba(0,229,255,0.12)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: 11,
        color: 'var(--color-accent)',
        flexShrink: 0,
      }}>{icon}</span>
      <span style={{ fontSize: 12 }}>{text}</span>
    </div>
  )
}

function SimReading({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
      <span style={{ fontSize: 11, color: 'var(--color-text-muted)' }}>{label}</span>
      <span style={{ fontSize: 12, fontWeight: 700, fontFamily: 'monospace', color }}>{value}</span>
    </div>
  )
}

function StatCard({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div style={{
      padding: '10px 12px',
      borderRadius: 8,
      border: '1px solid var(--color-border)',
      background: 'var(--color-surface-high)',
      textAlign: 'center',
    }}>
      <div style={{ fontSize: 20, fontWeight: 700, color, fontFamily: 'monospace', lineHeight: 1 }}>{value}</div>
      <div style={{ fontSize: 10, color: 'var(--color-text-muted)', marginTop: 4, letterSpacing: '0.08em' }}>{label.toUpperCase()}</div>
    </div>
  )
}
