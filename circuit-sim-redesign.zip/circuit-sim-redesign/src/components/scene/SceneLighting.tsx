import { useRef } from 'react'
import type { DirectionalLight } from 'three'

export default function SceneLighting() {
  const keyRef = useRef<DirectionalLight>(null!)

  return (
    <>
      {/* Ambient — cool blue-ish, labs feel */}
      <ambientLight intensity={0.35} color="#8ca8d0" />

      {/* Key light — warm overhead */}
      <directionalLight
        ref={keyRef}
        position={[6, 16, 5]}
        intensity={2.8}
        color="#ffe5b4"
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
        shadow-camera-near={0.5}
        shadow-camera-far={80}
        shadow-camera-left={-18}
        shadow-camera-right={18}
        shadow-camera-top={18}
        shadow-camera-bottom={-18}
        shadow-bias={-0.0002}
        shadow-normalBias={0.018}
      />

      {/* Fill — cool blue from left */}
      <directionalLight
        position={[-8, 10, -3]}
        intensity={1.0}
        color="#90b8f8"
        castShadow={false}
      />

      {/* Back-rim — rim light for component silhouettes */}
      <directionalLight
        position={[2, 4, -12]}
        intensity={0.55}
        color="#c0d8ff"
        castShadow={false}
      />

      {/* Accent: cyan lab glow from above */}
      <pointLight position={[0, 8, -6]} intensity={2.2} color="#00e5ff" distance={30} decay={2} />

      {/* Warm table bounce */}
      <pointLight position={[0, 0.6, 0]} intensity={0.5} color="#ffe4b0" distance={14} decay={2} />

      {/* Green PCB glow */}
      <pointLight position={[-3, 1.5, 2]} intensity={0.7} color="#00ff87" distance={12} decay={2.5} />

      {/* Amber warm fill */}
      <pointLight position={[4, 2, -1]} intensity={0.55} color="#f59e0b" distance={12} decay={2.5} />

      {/* Hemisphere for sky feel */}
      <hemisphereLight args={['#1a2a4a', '#0d1f12', 0.4]} />
    </>
  )
}
