import type { CircuitNode } from '@/types'
import Resistor from '../resistor/Resistor'
import Battery from '../battery/Battery'

interface CircuitComponentProps {
  node: CircuitNode
  selected?: boolean
}

/**
 * Dispatches a CircuitNode to its concrete 3D component based on `node.type`.
 * This is the main integration point between the data model and the render layer.
 */
export default function CircuitComponent({ node, selected = false }: CircuitComponentProps) {
  const pos: [number, number, number] = [node.position.x, node.position.y, node.position.z]
  const rot: [number, number, number] = [node.rotation.x, node.rotation.y, node.rotation.z]

  switch (node.type) {
    case 'resistor':
      return (
        <Resistor
          position={pos}
          rotation={rot}
          value={String(node.properties.value ?? '1kΩ')}
          selected={selected}
        />
      )

    case 'voltage-source':
      return (
        <Battery
          position={pos}
          rotation={rot}
          voltage={String(node.properties.voltage ?? '9V')}
          chargeLevel={Number(node.properties.chargeLevel ?? 1)}
          selected={selected}
        />
      )

    // Future components — return null until implemented
    case 'capacitor':
    case 'inductor':
    case 'ground':
    case 'wire':
    default:
      return null
  }
}
