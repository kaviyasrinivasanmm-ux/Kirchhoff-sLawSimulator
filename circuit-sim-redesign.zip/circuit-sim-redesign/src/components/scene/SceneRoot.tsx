import { Grid } from '@react-three/drei'
import CameraRig from './CameraRig'
import SceneLighting from './SceneLighting'
import Lab from './Lab'
import ComponentLayer from './ComponentLayer'
import WireLayer from './WireLayer'
import InteractionPlane from './InteractionPlane'
import PlacementGhost from './PlacementGhost'

export default function SceneRoot() {
  return (
    <>
      <CameraRig />
      <SceneLighting />
      <Lab />
      <Grid
        args={[60, 60]}
        position={[0, 0.006, 0]}
        cellSize={0.5}
        cellThickness={0.25}
        cellColor="#0d3018"
        sectionSize={2}
        sectionThickness={0.5}
        sectionColor="#134d25"
        fadeDistance={24}
        fadeStrength={1.8}
        followCamera={false}
        infiniteGrid
      />
      <InteractionPlane />
      <PlacementGhost />
      <ComponentLayer />
      <WireLayer />
    </>
  )
}
