import { ContactShadows } from '@react-three/drei'
import * as THREE from 'three'

export default function Lab() {
  return (
    <group>
      {/* Main floor */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
        <planeGeometry args={[60, 60]} />
        <meshStandardMaterial color="#080b12" roughness={0.9} metalness={0.0} />
      </mesh>

      {/* PCB-green work surface */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.001, 0]} receiveShadow>
        <planeGeometry args={[14, 9]} />
        <meshStandardMaterial color="#0d2b1a" roughness={0.92} metalness={0.02} transparent opacity={0.95} />
      </mesh>

      {/* PCB edge lines — subtle grid of traces */}
      <PCBTraces />

      {/* Subtle inner highlight on work surface */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.002, 0]}>
        <planeGeometry args={[13.8, 8.8]} />
        <meshStandardMaterial
          color="#0f3520"
          roughness={0.85}
          metalness={0.04}
          transparent
          opacity={0.3}
        />
      </mesh>

      {/* Contact shadows */}
      <ContactShadows
        position={[0, 0.004, 0]}
        opacity={0.75}
        scale={20}
        blur={3}
        far={1.8}
        resolution={512}
        color="#000000"
      />

      {/* Reflective polish layer */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.012, 0]} receiveShadow>
        <planeGeometry args={[60, 60]} />
        <meshStandardMaterial
          color="#040608"
          roughness={0.08}
          metalness={0.6}
          transparent
          opacity={0.5}
        />
      </mesh>

      {/* Back wall */}
      <mesh position={[0, 5, -16]} receiveShadow>
        <planeGeometry args={[60, 14]} />
        <meshStandardMaterial color="#06080f" roughness={1} metalness={0} />
      </mesh>

      {/* Left wall */}
      <mesh rotation={[0, Math.PI / 2, 0]} position={[-22, 5, 0]} receiveShadow>
        <planeGeometry args={[40, 14]} />
        <meshStandardMaterial color="#070a14" roughness={1} metalness={0} />
      </mesh>

      {/* Right wall */}
      <mesh rotation={[0, -Math.PI / 2, 0]} position={[22, 5, 0]} receiveShadow>
        <planeGeometry args={[40, 14]} />
        <meshStandardMaterial color="#070a14" roughness={1} metalness={0} />
      </mesh>
    </group>
  )
}

function PCBTraces() {
  // Horizontal PCB trace lines
  const hLines: JSX.Element[] = []
  const vLines: JSX.Element[] = []

  for (let i = -4; i <= 4; i++) {
    hLines.push(
      <mesh key={`h${i}`} rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.003, i * 1]}>
        <planeGeometry args={[13.6, 0.008]} />
        <meshBasicMaterial color="#164a28" transparent opacity={0.5} />
      </mesh>
    )
  }
  for (let i = -6; i <= 6; i++) {
    vLines.push(
      <mesh key={`v${i}`} rotation={[-Math.PI / 2, 0, 0]} position={[i * 1, 0.003, 0]}>
        <planeGeometry args={[0.008, 8.6]} />
        <meshBasicMaterial color="#164a28" transparent opacity={0.5} />
      </mesh>
    )
  }

  return <group>{hLines}{vLines}</group>
}
