import { useRef, useEffect } from 'react'
import { PerspectiveCamera, OrbitControls } from '@react-three/drei'
import { useFrame, useThree } from '@react-three/fiber'
import useInteractionStore from '@/store/useInteractionStore'

export default function CameraRig() {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const controlsRef = useRef<any>(null)
  const { gl } = useThree()

  // Track active touch count to distinguish single-touch (pan) from two-finger (rotate)
  const touchCount = useRef(0)

  useEffect(() => {
    const canvas = gl.domElement

    const onTouchStart = (e: TouchEvent) => {
      touchCount.current = e.touches.length
      if (controlsRef.current) {
        // Single touch = pan only, two fingers = rotate allowed
        controlsRef.current.enableRotate = e.touches.length >= 2
      }
    }

    const onTouchEnd = (e: TouchEvent) => {
      touchCount.current = e.touches.length
      if (controlsRef.current) {
        controlsRef.current.enableRotate = e.touches.length >= 2
      }
    }

    canvas.addEventListener('touchstart', onTouchStart, { passive: true })
    canvas.addEventListener('touchend', onTouchEnd, { passive: true })
    return () => {
      canvas.removeEventListener('touchstart', onTouchStart)
      canvas.removeEventListener('touchend', onTouchEnd)
    }
  }, [gl])

  useFrame(() => {
    if (!controlsRef.current) return
    const mode = useInteractionStore.getState().mode
    // Disable rotate while dragging/placing/wiring components
    if (mode === 'dragging' || mode === 'placing' || mode === 'wiring') {
      controlsRef.current.enableRotate = false
    } else if (touchCount.current < 2) {
      // Mouse: always allow rotate; touch single-finger: no rotate
      controlsRef.current.enableRotate = touchCount.current === 0
    }
  })

  return (
    <>
      <PerspectiveCamera
        makeDefault
        position={[0, 7, 11]}
        fov={50}
        near={0.05}
        far={500}
      />
      <OrbitControls
        ref={controlsRef}
        makeDefault
        enableDamping
        dampingFactor={0.06}
        enablePan
        panSpeed={0.8}
        enableZoom
        zoomSpeed={0.9}
        enableRotate
        rotateSpeed={0.6}
        minDistance={1.5}
        maxDistance={30}
        minPolarAngle={0.1}
        maxPolarAngle={Math.PI / 2.05}
        target={[0, 0, 0]}
        touches={{
          ONE: 2,  // ONE finger = PAN (THREE.TOUCH.PAN = 2)
          TWO: 1,  // TWO fingers = ROTATE_AND_DOLLY (THREE.TOUCH.ROTATE = 0, DOLLY_ROTATE = 1)
        }}
      />
    </>
  )
}
