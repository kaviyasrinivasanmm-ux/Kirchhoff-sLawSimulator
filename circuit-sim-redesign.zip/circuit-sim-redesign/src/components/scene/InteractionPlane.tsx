import { useRef } from 'react'
import type { Mesh } from 'three'
import { useDragHandler } from '@/hooks/useDragHandler'
import { usePlacement } from '@/hooks/usePlacement'
import { useWiring } from '@/hooks/useWiring'
import useInteractionStore from '@/store/useInteractionStore'
import useCircuitStore from '@/store/useCircuitStore'

export default function InteractionPlane() {
  const planeRef = useRef<Mesh>(null)

  const drag = useDragHandler()
  const placement = usePlacement()
  const wiring = useWiring()

  const mode = useInteractionStore((s) => s.mode)
  const wireTool = useInteractionStore((s) => s.wireTool)
  const selectNode = useCircuitStore((s) => s.selectNode)
  const cancelWiring = useInteractionStore((s) => s.cancelWiring)
  const disableWireTool = useInteractionStore((s) => s.disableWireTool)

  return (
    <mesh
      ref={planeRef}
      rotation={[-Math.PI / 2, 0, 0]}
      position={[0, 0.14, 0]}
      renderOrder={-1}
      visible
      onPointerMove={(e) => {
        drag.onPointerMove(e)
        placement.onPointerMove(e)
        wiring.onPointerMove(e)
      }}
      onPointerUp={drag.onPointerUp}
      onClick={(e) => {
        if (mode === 'placing') {
          placement.onClick(e)
        } else if (mode === 'wiring') {
          // Click on empty space cancels the current wiring segment
          // but keeps wire-tool active for a new attempt
          wiring.onClick(e)
        } else if (mode === 'idle') {
          selectNode(null)
        }
      }}
      onContextMenu={(e) => {
        placement.onContextMenu(e)
        // Right-click cancels wiring + deactivates wire tool
        if (mode === 'wiring' || wireTool) {
          e.stopPropagation()
          cancelWiring()
          disableWireTool()
        }
      }}
    >
      <planeGeometry args={[200, 200]} />
      <meshBasicMaterial transparent opacity={0} depthWrite={false} />
    </mesh>
  )
}
