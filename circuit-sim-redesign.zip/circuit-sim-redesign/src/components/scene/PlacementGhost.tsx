import { useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import type { Group } from 'three'
import useInteractionStore from '@/store/useInteractionStore'

export default function PlacementGhost() {
  const groupRef = useRef<Group>(null)
  const ringRef = useRef<THREE.Mesh>(null)

  useFrame((state) => {
    const ghost = useInteractionStore.getState().ghost
    if (!groupRef.current) return
    if (!ghost) {
      groupRef.current.visible = false
      return
    }
    groupRef.current.visible = true
    groupRef.current.position.set(ghost.position.x, ghost.position.y + 0.06, ghost.position.z)
    groupRef.current.rotation.set(ghost.rotation.x, ghost.rotation.y, ghost.rotation.z)

    // Animate ring
    if (ringRef.current) {
      const t = state.clock.elapsedTime
      const mat = ringRef.current.material as THREE.MeshBasicMaterial
      mat.opacity = ghost.snapped
        ? 0.8 + Math.sin(t * 8) * 0.15
        : 0.4 + Math.sin(t * 4) * 0.1
      ringRef.current.scale.setScalar(ghost.snapped
        ? 1 + Math.sin(t * 8) * 0.04
        : 1 + Math.sin(t * 3) * 0.03
      )
    }
  })

  const ghost = useInteractionStore((s) => s.ghost)
  if (!ghost) return null

  const isResistor = ghost.type === 'resistor' || ghost.type === 'capacitor' || ghost.type === 'inductor'
  const isBattery  = ghost.type === 'voltage-source'
  const snapColor  = ghost.snapped ? '#00ff87' : '#00e5ff'

  return (
    <group ref={groupRef}>
      {/* Ghost body */}
      {isResistor && (
        <mesh rotation={[0, 0, Math.PI / 2]}>
          <capsuleGeometry args={[0.145, 0.82, 8, 18]} />
          <meshStandardMaterial color="#00e5ff" transparent opacity={0.22} />
        </mesh>
      )}

      {isBattery && (
        <mesh>
          <cylinderGeometry args={[0.24, 0.24, 1.24, 28]} />
          <meshStandardMaterial color="#00e5ff" transparent opacity={0.22} />
        </mesh>
      )}

      {/* Glow aura */}
      {isResistor && (
        <mesh rotation={[0, 0, Math.PI / 2]}>
          <capsuleGeometry args={[0.22, 0.9, 6, 12]} />
          <meshBasicMaterial color={snapColor} transparent opacity={0.06} />
        </mesh>
      )}
      {isBattery && (
        <mesh>
          <cylinderGeometry args={[0.34, 0.34, 1.36, 18]} />
          <meshBasicMaterial color={snapColor} transparent opacity={0.06} />
        </mesh>
      )}

      {/* Snap ring */}
      <mesh ref={ringRef} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[0.40, 0.45, 36]} />
        <meshBasicMaterial
          color={snapColor}
          transparent
          opacity={0.6}
          side={THREE.DoubleSide}
        />
      </mesh>

      {/* Centre dot */}
      <mesh position={[0, 0.01, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <circleGeometry args={[0.055, 20]} />
        <meshBasicMaterial color={snapColor} />
      </mesh>

      {/* Corner markers */}
      {[[0.5, 0.5], [0.5, -0.5], [-0.5, 0.5], [-0.5, -0.5]].map(([x, z], i) => (
        <mesh key={i} position={[x, 0.01, z]} rotation={[-Math.PI / 2, 0, 0]}>
          <circleGeometry args={[0.03, 8]} />
          <meshBasicMaterial color={snapColor} transparent opacity={0.5} />
        </mesh>
      ))}
    </group>
  )
}
