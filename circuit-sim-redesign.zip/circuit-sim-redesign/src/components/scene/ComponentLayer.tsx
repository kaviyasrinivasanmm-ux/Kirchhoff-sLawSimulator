import { useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import useCircuitStore from '@/store/useCircuitStore'
import useInteractionStore from '@/store/useInteractionStore'
import { useComponentInteraction } from '@/hooks/useComponentInteraction'
import { useComponentWireInteraction } from '@/hooks/useWiring'
import Resistor from '@/components/resistor/Resistor'
import Battery from '@/components/battery/Battery'
import type { CircuitNode } from '@/types'

export default function ComponentLayer() {
  const nodes = useCircuitStore((s) => s.nodes)
  return (
    <group name="components">
      {nodes.map((node) => (
        <InteractiveNode key={node.id} node={node} />
      ))}
    </group>
  )
}

function InteractiveNode({ node }: { node: CircuitNode }) {
  const groupRef = useRef<THREE.Group>(null)
  const hoverShellRef = useRef<THREE.Mesh>(null)
  const wireGlowRef = useRef<THREE.Group>(null)

  const handlers = useComponentInteraction(node.id)
  const wireHandlers = useComponentWireInteraction(node.id)

  const isSelected = useCircuitStore((s) => s.selectedId === node.id)
  const isHovered = useInteractionStore(
    (s) => s.hoveredId === node.id && !s.wireTool && s.mode !== 'wiring'
  )
  const isWireHovered = useInteractionStore(
    (s) => s.wireHoveredNodeId === node.id
  )
  const isWireFrom = useInteractionStore(
    (s) => s.wiring?.fromNodeId === node.id
  )
  const wireTool = useInteractionStore((s) => s.wireTool)
  const wiringMode = useInteractionStore((s) => s.mode === 'wiring')

  useFrame((state) => {
    const t = state.clock.elapsedTime

    // Sync position on drag
    if (groupRef.current) {
      const drag = useInteractionStore.getState().drag
      if (drag && drag.nodeId === node.id) {
        const live = useCircuitStore.getState().nodes.find((n) => n.id === node.id)
        if (live) groupRef.current.position.set(live.position.x, live.position.y, live.position.z)
      }
    }

    // Hover shell animation
    if (hoverShellRef.current) {
      const mat = hoverShellRef.current.material as THREE.MeshBasicMaterial
      if (isHovered) {
        mat.opacity = 0.04 + Math.sin(t * 4) * 0.01
      } else {
        mat.opacity = 0
      }
    }

    // Wire-tool glow pulse
    if (wireGlowRef.current) {
      const glow = isWireFrom ? '#ffaa00' : '#00e5ff'
      wireGlowRef.current.children.forEach((child: any) => {
        if (child.material) {
          if (isWireFrom) {
            child.material.opacity = 0.14 + Math.sin(t * 5) * 0.07
          } else if (isWireHovered) {
            child.material.opacity = 0.1 + Math.sin(t * 4) * 0.05
          } else {
            child.material.opacity = 0.025
          }
        }
      })
    }
  })

  const pos: [number, number, number] = [node.position.x, node.position.y, node.position.z]
  const rot: [number, number, number] = [node.rotation.x, node.rotation.y, node.rotation.z]

  const combinedHandlers = {
    onClick: (e: any) => {
      handlers.onClick(e)
      wireHandlers.onClick(e)
    },
    onPointerEnter: (e: any) => {
      handlers.onPointerEnter(e)
      wireHandlers.onPointerEnter(e)
    },
    onPointerLeave: (e: any) => {
      handlers.onPointerLeave(e)
      wireHandlers.onPointerLeave(e)
    },
    onPointerDown: handlers.onPointerDown,
  }

  const showWireGlow = wireTool || wiringMode
  const glowColor = isWireFrom ? '#ffaa00' : '#00e5ff'

  return (
    <group ref={groupRef} {...combinedHandlers}>
      {/* Hover glow shell — large easy-to-hit zone */}
      <mesh ref={hoverShellRef} position={pos}>
        <sphereGeometry args={[0.85, 16, 16]} />
        <meshBasicMaterial color="#ffffff" transparent opacity={0} depthWrite={false} />
      </mesh>

      {/* Wire-tool interaction zone + glow feedback */}
      {showWireGlow && (
        <group ref={wireGlowRef} position={pos}>
          {/* Large hit zone / inner glow */}
          <mesh>
            <sphereGeometry args={[0.9, 16, 16]} />
            <meshBasicMaterial
              color={glowColor}
              transparent
              opacity={isWireFrom ? 0.14 : isWireHovered ? 0.1 : 0.025}
              depthWrite={false}
            />
          </mesh>
          {/* Outer wireframe ring */}
          <mesh>
            <sphereGeometry args={[1.05, 10, 10]} />
            <meshBasicMaterial
              color={glowColor}
              transparent
              opacity={isWireFrom || isWireHovered ? 0.06 : 0.015}
              wireframe
              depthWrite={false}
            />
          </mesh>
        </group>
      )}

      {/* Hover outline ring */}
      {isHovered && !showWireGlow && (
        <mesh position={pos} rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[0.7, 0.012, 8, 48]} />
          <meshBasicMaterial color="#ffffff" transparent opacity={0.12} />
        </mesh>
      )}

      {node.type === 'resistor' && (
        <Resistor
          position={pos}
          rotation={rot}
          value={String(node.properties.value ?? '1kΩ')}
          selected={isSelected}
          nodeId={node.id}
        />
      )}
      {node.type === 'voltage-source' && (
        <Battery
          position={pos}
          rotation={rot}
          voltage={String(node.properties.voltage ?? '9V')}
          chargeLevel={Number(node.properties.chargeLevel ?? 1)}
          selected={isSelected}
          nodeId={node.id}
        />
      )}
      {(node.type === 'capacitor' || node.type === 'inductor' || node.type === 'ground') && (
        <group position={pos}>
          <mesh>
            <boxGeometry args={[0.55, 0.35, 0.35]} />
            <meshStandardMaterial color="#5c6ef8" roughness={0.4} metalness={0.5} />
          </mesh>
          {isSelected && (
            <mesh>
              <boxGeometry args={[0.72, 0.5, 0.5]} />
              <meshBasicMaterial color="#00e5ff" transparent opacity={0.06} wireframe />
            </mesh>
          )}
        </group>
      )}
    </group>
  )
}
