import { useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { CatmullRomLine } from '@react-three/drei'
import * as THREE from 'three'
import useCircuitStore from '@/store/useCircuitStore'
import useInteractionStore from '@/store/useInteractionStore'
import Terminal from '../shared/Terminal'
import { buildWirePath } from '@/utils/geometry'

// ─────────────────────────────────────────────────────────────────────────────
// WireLayer — beautiful wire rendering with glow, thickness, and animations
// ─────────────────────────────────────────────────────────────────────────────

export default function WireLayer() {
  const wires = useCircuitStore((s) => s.wires)
  const nodes = useCircuitStore((s) => s.nodes)
  const removeWire = useCircuitStore((s) => s.removeWire)

  return (
    <group name="wires">
      {wires.map((wire) => {
        const fromNode = nodes.find((n) => n.id === wire.from)
        const toNode = nodes.find((n) => n.id === wire.to)
        if (!fromNode || !toNode) return null

        const pts = wire.points.map(
          (p): [number, number, number] => [p.x, p.y, p.z]
        )
        if (pts.length < 2) return null

        return (
          <CommittedWire
            key={wire.id}
            pts={pts}
            wireId={wire.id}
            onDelete={() => removeWire(wire.id)}
          />
        )
      })}
      <WirePreview />
    </group>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// CommittedWire — a fully placed wire with gorgeous rendering
// ─────────────────────────────────────────────────────────────────────────────

interface CommittedWireProps {
  pts: [number, number, number][]
  wireId: string
  onDelete: () => void
}

function CommittedWire({ pts, onDelete }: CommittedWireProps) {
  const deleteHitRef = useRef<THREE.Mesh>(null)
  const [hovered, setHovered] = (useRef(false), [false, () => {}])
  // Use local state for hover
  const isHoveredRef = useRef(false)
  const lineGroupRef = useRef<THREE.Group>(null)

  useFrame(() => {
    if (!lineGroupRef.current) return
  })

  const midPt: [number, number, number] = [
    (pts[0][0] + pts[pts.length - 1][0]) / 2,
    Math.max(...pts.map(p => p[1])) + 0.08,
    (pts[0][2] + pts[pts.length - 1][2]) / 2,
  ]

  return (
    <group ref={lineGroupRef}>
      {/* Shadow wire (slightly wider, dark) */}
      <CatmullRomLine
        points={pts}
        color="#000000"
        lineWidth={7}
        segments={pts.length * 12}
        closed={false}
        transparent
        opacity={0.35}
      />

      {/* Core wire — amber/gold */}
      <CatmullRomLine
        points={pts}
        color="#f59e0b"
        lineWidth={4.5}
        segments={pts.length * 20}
        closed={false}
      />

      {/* Glow sheen */}
      <CatmullRomLine
        points={pts}
        color="#fde68a"
        lineWidth={1.8}
        segments={pts.length * 20}
        closed={false}
        transparent
        opacity={0.6}
      />

      {/* Endpoints — metallic solder joints */}
      <Terminal position={pts[0]} color="#e5c040" radius={0.052} emissive glowColor="#f59e0b" />
      <Terminal position={pts[pts.length - 1]} color="#e5c040" radius={0.052} emissive glowColor="#f59e0b" />

      {/* Delete zone — invisible sphere at midpoint */}
      <mesh
        ref={deleteHitRef}
        position={midPt}
        onClick={(e) => {
          e.stopPropagation()
          const store = useInteractionStore.getState()
          if (store.mode === 'idle' && !store.wireTool) {
            onDelete()
          }
        }}
        onPointerEnter={(e) => {
          e.stopPropagation()
          isHoveredRef.current = true
          document.body.style.cursor = 'pointer'
        }}
        onPointerLeave={() => {
          isHoveredRef.current = false
          document.body.style.cursor = ''
        }}
      >
        <sphereGeometry args={[0.22, 8, 8]} />
        <meshBasicMaterial transparent opacity={0} />
      </mesh>
    </group>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// WirePreview — live wire preview with beautiful cyan glow
// ─────────────────────────────────────────────────────────────────────────────

function WirePreview() {
  const groupRef = useRef<THREE.Group>(null)
  const flowRef = useRef(0)

  useFrame((state) => {
    flowRef.current = state.clock.elapsedTime
    const { wiring } = useInteractionStore.getState()
    if (!groupRef.current) return
    groupRef.current.visible = !!(wiring && wiring.previewEnd)
  })

  const wiring = useInteractionStore((s) => s.wiring)
  if (!wiring || !wiring.previewEnd) return <group ref={groupRef} />

  const from = wiring.fromPosition
  const to = wiring.previewEnd
  const pathPoints = buildWirePath(from, to)
  const pts: [number, number, number][] = pathPoints.map(p => [p.x, p.y, p.z])

  const snapTarget = wiring.snapTarget

  return (
    <group ref={groupRef}>
      {/* Shadow */}
      <CatmullRomLine
        points={pts}
        color="#000000"
        lineWidth={6}
        segments={pts.length * 16}
        closed={false}
        transparent
        opacity={0.25}
      />

      {/* Main preview wire — electric cyan */}
      <CatmullRomLine
        points={pts}
        color="#00e5ff"
        lineWidth={3.5}
        segments={pts.length * 24}
        closed={false}
        transparent
        opacity={0.9}
      />

      {/* Bright core */}
      <CatmullRomLine
        points={pts}
        color="#ffffff"
        lineWidth={1.2}
        segments={pts.length * 24}
        closed={false}
        transparent
        opacity={0.45}
      />

      {/* Source terminal — orange pulsing */}
      <Terminal
        position={[from.x, from.y, from.z]}
        color="#ffaa00"
        radius={0.075}
        emissive
        isSource
      />

      {/* Snap target indicator */}
      {snapTarget ? (
        <Terminal
          position={[to.x, to.y, to.z]}
          color="#00ff87"
          radius={0.085}
          emissive
          isSnapping
        />
      ) : (
        /* Cursor dot when not snapped */
        <Terminal
          position={[to.x, to.y, to.z]}
          color="#00e5ff"
          radius={0.055}
          emissive
        />
      )}
    </group>
  )
}
