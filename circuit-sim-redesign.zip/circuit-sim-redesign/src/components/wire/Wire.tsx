import { CatmullRomLine } from '@react-three/drei'
import * as THREE from 'three'
import Terminal from '../shared/Terminal'

export interface WireProps {
  points: [number, number, number][]
  color?: string
  radius?: number
  showTerminals?: boolean
  opacity?: number
}

export default function Wire({
  points,
  color = '#dc2626',
  radius = 0.035,
  showTerminals = true,
  opacity = 1,
}: WireProps) {
  const safePoints: [number, number, number][] =
    points.length >= 2 ? points : [[0, 0, 0], [1, 0, 0]]

  const start = safePoints[0]
  const end = safePoints[safePoints.length - 1]
  const highlightColor = new THREE.Color(color).lerp(new THREE.Color('#ffffff'), 0.55).getStyle()

  return (
    <group>
      <CatmullRomLine
        points={safePoints}
        color={color}
        lineWidth={radius * 120}
        segments={safePoints.length * 16}
        closed={false}
        transparent={opacity < 1}
        opacity={opacity}
      />
      <CatmullRomLine
        points={safePoints}
        color={highlightColor}
        lineWidth={radius * 30}
        segments={safePoints.length * 16}
        closed={false}
        transparent
        opacity={opacity * 0.45}
      />
      {showTerminals && (
        <>
          <Terminal position={start} color="#b8b8b8" radius={0.055} />
          <Terminal position={end} color="#b8b8b8" radius={0.055} />
        </>
      )}
    </group>
  )
}
