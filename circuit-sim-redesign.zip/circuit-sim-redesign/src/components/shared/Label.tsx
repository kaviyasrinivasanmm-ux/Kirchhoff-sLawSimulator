import { Text } from '@react-three/drei'

export interface LabelProps {
  text: string
  position: [number, number, number]
  fontSize?: number
  color?: string
  anchorX?: 'left' | 'center' | 'right'
  anchorY?: 'top' | 'middle' | 'bottom'
}

export default function Label({
  text,
  position,
  fontSize = 0.18,
  color = '#94a3b8',
  anchorX = 'center',
  anchorY = 'middle',
}: LabelProps) {
  return (
    <Text
      position={position}
      fontSize={fontSize}
      color={color}
      anchorX={anchorX}
      anchorY={anchorY}
      outlineColor="#000000"
      outlineOpacity={0.5}
      outlineWidth={0.006}
    >
      {text}
    </Text>
  )
}
