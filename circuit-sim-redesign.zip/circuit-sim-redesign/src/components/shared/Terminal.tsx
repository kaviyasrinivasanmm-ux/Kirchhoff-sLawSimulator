import { useRef, useState } from 'react'
import { useFrame } from '@react-three/fiber'
import type { Mesh } from 'three'
import type { ThreeEvent } from '@react-three/fiber'

// ─────────────────────────────────────────────────────────────────
// Terminal  – redesigned solder-joint sphere with animated glow
// Much larger interaction zones, beautiful hover states
// ─────────────────────────────────────────────────────────────────

export interface TerminalProps {
  position: [number, number, number]
  color?: string
  radius?: number
  emissive?: boolean
  glowColor?: string
  onClick?: (e: ThreeEvent<MouseEvent>) => void
  onPointerEnter?: (e: ThreeEvent<PointerEvent>) => void
  onPointerLeave?: (e: ThreeEvent<PointerEvent>) => void
  interactive?: boolean
  isSnapping?: boolean
  isSource?: boolean
}

export default function Terminal({
  position,
  color = '#c8c8c8',
  radius = 0.06,
  emissive = false,
  glowColor,
  onClick,
  onPointerEnter,
  onPointerLeave,
  interactive = false,
  isSnapping = false,
  isSource = false,
}: TerminalProps) {
  const meshRef = useRef<Mesh>(null)
  const outerRingRef = useRef<Mesh>(null)
  const [hovered, setHovered] = useState(false)

  useFrame((state) => {
    if (!meshRef.current) return
    const t = state.clock.elapsedTime

    if (isSnapping) {
      // Breathing glow effect when snapping
      const scale = 1 + Math.sin(t * 8) * 0.15
      meshRef.current.scale.setScalar(scale)
      if (outerRingRef.current) {
        outerRingRef.current.scale.setScalar(1 + Math.sin(t * 6) * 0.12)
        const mat = outerRingRef.current.material as any
        if (mat) mat.opacity = 0.6 + Math.sin(t * 6) * 0.3
      }
    } else if (isSource) {
      const scale = 1 + Math.sin(t * 4) * 0.08
      meshRef.current.scale.setScalar(scale)
    } else if (hovered && interactive) {
      meshRef.current.scale.setScalar(1.3)
    } else {
      meshRef.current.scale.setScalar(1)
    }
  })

  const handleEnter = (e: ThreeEvent<PointerEvent>) => {
    setHovered(true)
    onPointerEnter?.(e)
  }
  const handleLeave = (e: ThreeEvent<PointerEvent>) => {
    setHovered(false)
    onPointerLeave?.(e)
  }

  const displayColor = hovered && interactive ? '#00e5ff'
    : isSnapping ? '#00ff87'
    : isSource ? '#ffaa00'
    : color

  const emissiveColor = hovered && interactive ? '#00e5ff'
    : isSnapping ? '#00ff87'
    : isSource ? '#ff9900'
    : emissive ? (glowColor ?? color)
    : '#000000'

  const emissiveIntensity = hovered && interactive ? 2.5
    : isSnapping ? 3.5
    : isSource ? 2.0
    : emissive ? 0.6
    : 0

  return (
    <group position={position}>
      {/* Invisible large hitbox for easy clicking */}
      {interactive && (
        <mesh
          onClick={onClick}
          onPointerEnter={handleEnter}
          onPointerLeave={handleLeave}
        >
          <sphereGeometry args={[radius * 4, 8, 8]} />
          <meshBasicMaterial transparent opacity={0} depthWrite={false} />
        </mesh>
      )}

      {/* Outer animated ring for snapping/source */}
      {(isSnapping || isSource) && (
        <mesh ref={outerRingRef} rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[radius * 2.8, radius * 0.18, 8, 32]} />
          <meshStandardMaterial
            color={isSnapping ? '#00ff87' : '#ffaa00'}
            emissive={isSnapping ? '#00ff87' : '#ffaa00'}
            emissiveIntensity={3}
            transparent
            opacity={0.85}
          />
        </mesh>
      )}

      {/* Hover ring */}
      {hovered && interactive && (
        <mesh rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[radius * 2.4, radius * 0.14, 8, 32]} />
          <meshStandardMaterial
            color="#00e5ff"
            emissive="#00e5ff"
            emissiveIntensity={2.5}
            transparent
            opacity={0.7}
          />
        </mesh>
      )}

      {/* Main terminal sphere */}
      <mesh ref={meshRef} castShadow>
        <sphereGeometry args={[radius, 16, 16]} />
        <meshStandardMaterial
          color={displayColor}
          metalness={isSnapping || isSource ? 0.2 : 0.9}
          roughness={0.1}
          emissive={emissiveColor}
          emissiveIntensity={emissiveIntensity}
        />
      </mesh>
    </group>
  )
}
