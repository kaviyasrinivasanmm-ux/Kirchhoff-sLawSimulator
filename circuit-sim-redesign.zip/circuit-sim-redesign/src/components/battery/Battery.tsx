import { useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import type { Group } from 'three'
import Terminal from '../shared/Terminal'
import { useTerminalInteraction } from '@/hooks/useWiring'

export interface BatteryProps {
  position?: [number, number, number]
  rotation?: [number, number, number]
  voltage?: string
  chargeLevel?: number
  selected?: boolean
  nodeId?: string
}

export default function Battery({
  position = [0, 0, 0],
  rotation = [0, 0, 0],
  chargeLevel = 1,
  selected = false,
  nodeId,
}: BatteryProps) {
  const groupRef = useRef<Group>(null)
  const selRingRef = useRef<any>(null)
  const phase = useRef(Math.random() * Math.PI * 2)

  useFrame((state) => {
    if (!groupRef.current) return
    const t = state.clock.elapsedTime

    if (selected) {
      groupRef.current.position.y =
        position[1] + Math.sin(t * 1.9 + phase.current) * 0.045
    } else {
      groupRef.current.position.y = position[1]
    }

    if (selRingRef.current && selected) {
      const mat = selRingRef.current.material
      if (mat) mat.emissiveIntensity = 2.0 + Math.sin(t * 2.8) * 0.8
    }
  })

  const clamped = Math.max(0.02, Math.min(1, chargeLevel))
  const chargeColor = clamped > 0.6 ? '#00ff87' : clamped > 0.3 ? '#fbbf24' : '#ff4d6d'

  const posTerminal = useTerminalInteraction(
    nodeId ?? '',
    'positive',
    { x: position[0], y: position[1] + 0.91, z: position[2] }
  )
  const negTerminal = useTerminalInteraction(
    nodeId ?? '',
    'negative',
    { x: position[0], y: position[1] - 0.86, z: position[2] }
  )

  return (
    <group ref={groupRef} position={[position[0], position[1], position[2]]} rotation={rotation}>
      {/* Body */}
      <mesh castShadow receiveShadow>
        <cylinderGeometry args={[0.22, 0.22, 1.22, 36]} />
        <meshStandardMaterial color="#1c1f2e" roughness={0.65} metalness={0.25} />
      </mesh>

      {/* Body highlight stripe */}
      <mesh position={[0, 0, 0.22]}>
        <cylinderGeometry args={[0.2201, 0.2201, 1.18, 36]} />
        <meshStandardMaterial color="#252840" roughness={0.8} metalness={0.1} transparent opacity={0.4} />
      </mesh>

      {/* Label band */}
      <mesh position={[0, 0.1, 0]}>
        <cylinderGeometry args={[0.225, 0.225, 0.42, 36]} />
        <meshStandardMaterial color="#f0f0f0" roughness={0.88} metalness={0} />
      </mesh>

      {/* Charge indicator — glows inside label band */}
      <mesh position={[0, 0.1 - (0.42 * (1 - clamped)) / 2, 0]}>
        <cylinderGeometry args={[0.227, 0.227, 0.40 * clamped, 36]} />
        <meshStandardMaterial
          color={chargeColor}
          emissive={chargeColor}
          emissiveIntensity={0.45}
          transparent
          opacity={0.9}
        />
      </mesh>

      {/* Positive cap */}
      <mesh position={[0, 0.66, 0]} castShadow>
        <cylinderGeometry args={[0.20, 0.22, 0.1, 36]} />
        <meshStandardMaterial color="#9ca3af" metalness={0.92} roughness={0.08} />
      </mesh>

      {/* Positive nub */}
      <mesh position={[0, 0.725, 0]} castShadow>
        <cylinderGeometry args={[0.062, 0.062, 0.055, 20]} />
        <meshStandardMaterial color="#d0d0d0" metalness={0.97} roughness={0.04} />
      </mesh>

      {/* Negative cap */}
      <mesh position={[0, -0.645, 0]} castShadow>
        <cylinderGeometry args={[0.22, 0.22, 0.085, 36]} />
        <meshStandardMaterial color="#6b7280" metalness={0.82} roughness={0.2} />
      </mesh>

      {/* Insulator ring */}
      <mesh position={[0, -0.596, 0]}>
        <torusGeometry args={[0.212, 0.018, 10, 36]} />
        <meshStandardMaterial color="#111827" roughness={1} />
      </mesh>

      {/* Positive pin */}
      <mesh position={[0, 0.82, 0]} castShadow>
        <cylinderGeometry args={[0.026, 0.026, 0.16, 12]} />
        <meshStandardMaterial color="#d4af37" metalness={0.99} roughness={0.04} />
      </mesh>

      {/* Negative pin */}
      <mesh position={[0, -0.775, 0]} castShadow>
        <cylinderGeometry args={[0.026, 0.026, 0.16, 12]} />
        <meshStandardMaterial color="#b0b0b0" metalness={0.96} roughness={0.07} />
      </mesh>

      {/* Interactive terminals */}
      <Terminal
        position={[0, 0.91, 0]}
        color="#d4af37"
        radius={0.058}
        emissive
        glowColor="#e5c040"
        interactive={!!nodeId}
        onClick={nodeId ? posTerminal.onClick : undefined}
        onPointerEnter={nodeId ? posTerminal.onPointerEnter : undefined}
        onPointerLeave={nodeId ? posTerminal.onPointerLeave : undefined}
      />
      <Terminal
        position={[0, -0.86, 0]}
        color="#9ca3af"
        radius={0.058}
        interactive={!!nodeId}
        onClick={nodeId ? negTerminal.onClick : undefined}
        onPointerEnter={nodeId ? negTerminal.onPointerEnter : undefined}
        onPointerLeave={nodeId ? negTerminal.onPointerLeave : undefined}
      />

      {/* Selection ring */}
      {selected && (
        <mesh ref={selRingRef}>
          <torusGeometry args={[0.35, 0.016, 10, 52]} />
          <meshStandardMaterial
            color="#00e5ff"
            emissive="#00e5ff"
            emissiveIntensity={2.5}
            transparent
            opacity={0.8}
          />
        </mesh>
      )}

      {/* Selection glow volume */}
      {selected && (
        <mesh>
          <cylinderGeometry args={[0.38, 0.38, 1.5, 24]} />
          <meshBasicMaterial color="#00e5ff" transparent opacity={0.025} />
        </mesh>
      )}
    </group>
  )
}
