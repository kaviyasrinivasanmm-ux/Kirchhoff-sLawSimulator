import { useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { RoundedBox } from '@react-three/drei'
import type { Group } from 'three'
import Terminal from '../shared/Terminal'
import { useTerminalInteraction } from '@/hooks/useWiring'

export interface ResistorProps {
  position?: [number, number, number]
  rotation?: [number, number, number]
  value?: string
  selected?: boolean
  bandColors?: [string, string, string, string]
  nodeId?: string
}

const BAND_X: [number, number, number, number] = [-0.27, -0.08, 0.11, 0.34]

const DEFAULT_BANDS: [string, string, string, string] = [
  '#8B4513',
  '#1a1a1a',
  '#ff6a00',
  '#d4af37',
]

export default function Resistor({
  position = [0, 0, 0],
  rotation = [0, 0, 0],
  selected = false,
  bandColors = DEFAULT_BANDS,
  nodeId,
}: ResistorProps) {
  const groupRef = useRef<Group>(null)
  const phaseRef = useRef(Math.random() * Math.PI * 2)
  const selectionRingRef = useRef<any>(null)

  useFrame((state) => {
    if (!groupRef.current) return
    const t = state.clock.elapsedTime

    if (selected) {
      groupRef.current.position.y =
        position[1] + Math.sin(t * 2.1 + phaseRef.current) * 0.04
    } else {
      groupRef.current.position.y = position[1]
    }

    // Animate selection ring
    if (selectionRingRef.current && selected) {
      const mat = selectionRingRef.current.material
      if (mat) {
        mat.emissiveIntensity = 2.5 + Math.sin(t * 3) * 1.0
        mat.opacity = 0.7 + Math.sin(t * 3) * 0.15
      }
    }
  })

  const leftTerminal = useTerminalInteraction(
    nodeId ?? '',
    'negative',
    { x: position[0], y: position[1], z: position[2] - 1.065 }
  )
  const rightTerminal = useTerminalInteraction(
    nodeId ?? '',
    'positive',
    { x: position[0], y: position[1], z: position[2] + 1.065 }
  )

  return (
    <group ref={groupRef} position={[position[0], position[1], position[2]]} rotation={rotation}>
      {/* Ceramic body — slightly wider look */}
      <RoundedBox args={[1.14, 0.30, 0.30]} radius={0.14} smoothness={8} castShadow receiveShadow>
        <meshStandardMaterial color="#d4b98a" roughness={0.52} metalness={0.04} />
      </RoundedBox>

      {/* Subtle top sheen */}
      <RoundedBox args={[1.10, 0.04, 0.28]} radius={0.04} smoothness={4} position={[0, 0.14, 0]}>
        <meshStandardMaterial color="#ede0c4" roughness={0.7} metalness={0.0} transparent opacity={0.4} />
      </RoundedBox>

      {/* Color-code bands */}
      {bandColors.map((col, i) => (
        <mesh key={i} position={[BAND_X[i], 0, 0]} castShadow>
          <cylinderGeometry args={[0.155, 0.155, 0.072, 32, 1]} />
          <meshStandardMaterial color={col} roughness={0.35} metalness={0.05} />
        </mesh>
      ))}

      {/* Leads */}
      <mesh position={[-0.82, 0, 0]} castShadow rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.020, 0.020, 0.46, 12, 1]} />
        <meshStandardMaterial color="#b8b8b8" metalness={0.95} roughness={0.08} />
      </mesh>
      <mesh position={[0.82, 0, 0]} castShadow rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.020, 0.020, 0.46, 12, 1]} />
        <meshStandardMaterial color="#b8b8b8" metalness={0.95} roughness={0.08} />
      </mesh>

      {/* Terminals — integrated into lead tips */}
      <Terminal
        position={[-1.065, 0, 0]}
        color="#c4c4c4"
        radius={0.050}
        interactive={!!nodeId}
        onClick={nodeId ? leftTerminal.onClick : undefined}
        onPointerEnter={nodeId ? leftTerminal.onPointerEnter : undefined}
        onPointerLeave={nodeId ? leftTerminal.onPointerLeave : undefined}
      />
      <Terminal
        position={[1.065, 0, 0]}
        color="#c4c4c4"
        radius={0.050}
        interactive={!!nodeId}
        onClick={nodeId ? rightTerminal.onClick : undefined}
        onPointerEnter={nodeId ? rightTerminal.onPointerEnter : undefined}
        onPointerLeave={nodeId ? rightTerminal.onPointerLeave : undefined}
      />

      {/* Selection ring */}
      {selected && (
        <mesh ref={selectionRingRef} rotation={[0, 0, Math.PI / 2]}>
          <torusGeometry args={[0.38, 0.014, 8, 64]} />
          <meshStandardMaterial
            color="#00e5ff"
            emissive="#00e5ff"
            emissiveIntensity={3.0}
            transparent
            opacity={0.85}
          />
        </mesh>
      )}

      {/* Selection inner glow  */}
      {selected && (
        <mesh>
          <boxGeometry args={[1.3, 0.5, 0.5]} />
          <meshBasicMaterial color="#00e5ff" transparent opacity={0.03} />
        </mesh>
      )}
    </group>
  )
}
