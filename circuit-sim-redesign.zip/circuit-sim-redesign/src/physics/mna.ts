// ─────────────────────────────────────────────────────────────────────────────
// mna.ts — Modified Nodal Analysis matrix assembly
//
// MNA formulates circuit analysis as a linear system:
//
//   ┌ G  B ┐ ┌ v ┐   ┌ i ┐
//   │      │ │   │ = │   │
//   └ C  D ┘ └ j ┘   └ e ┘
//
// Where:
//   n = number of non-ground nodes
//   m = number of independent voltage sources
//   size = n + m
//
//   G (n×n): conductance matrix
//     G[k][k] += sum of conductances connected to node k
//     G[k][j] -= conductance between nodes k and j
//
//   B (n×m): voltage-source incidence matrix
//     B[k][s] = +1 if positive terminal of source s connects to node k
//     B[k][s] = -1 if negative terminal of source s connects to node k
//
//   C (m×n): transpose of B
//
//   D (m×m): zero for ideal voltage sources
//
//   v (n×1): unknown node voltages
//   j (m×1): unknown branch currents through voltage sources
//   i (n×1): known current injections (from current sources — 0 here)
//   e (m×1): known voltage source EMF values
//
// Reference: Pillage, Rohrer, Visweswariah — "Electronic Circuit & System
//            Simulation Methods", McGraw-Hill 1995, Ch. 3
// ─────────────────────────────────────────────────────────────────────────────

import type { Netlist, MNASystem } from './types'
import { zeros, stamp } from './matrix'

/**
 * Assemble the MNA augmented matrix from a Netlist.
 *
 * Returns an MNASystem ready for Gaussian elimination.
 */
export function assembleMNA(netlist: Netlist): MNASystem {
  const { nodes, elements, groundId, nodeCount, voltageSourceCount } = netlist
  const size = nodeCount + voltageSourceCount
  const vsOffset = nodeCount

  // Augmented matrix [A | b], initialised to zero
  // Size: (size) rows × (size + 1) cols
  const aug: number[][] = zeros(size, size + 1)

  // Track which voltage-source index we're at
  let vsIdx = 0

  // Helper: get the MNA row/col index for a node root
  // Ground node returns -1 (excluded from matrix)
  const nodeIndex = (root: string): number => {
    if (root === groundId) return -1
    return nodes.get(root)?.index ?? -1
  }

  for (const el of elements) {
    const p = nodeIndex(el.nodePos)
    const n = nodeIndex(el.nodeNeg)

    switch (el.kind) {
      // ── Resistor / Capacitor(DC) / Inductor(DC) / Wire ──────────────
      // Stamp conductance G = 1/R into the G sub-matrix:
      //   G[p][p] += G
      //   G[n][n] += G
      //   G[p][n] -= G
      //   G[n][p] -= G
      case 'resistor':
      case 'capacitor':
      case 'inductor':
      case 'wire': {
        const G = 1 / el.value  // conductance in siemens
        if (p >= 0) stamp(aug, p, p,  G)
        if (n >= 0) stamp(aug, n, n,  G)
        if (p >= 0 && n >= 0) {
          stamp(aug, p, n, -G)
          stamp(aug, n, p, -G)
        }
        break
      }

      // ── Independent voltage source ───────────────────────────────────
      // Stamps into the B, C, and e regions:
      //   B[p][s] += +1  (positive terminal at node p)
      //   B[n][s] += -1  (negative terminal at node n)
      //   C[s][p] += +1
      //   C[s][n] += -1
      //   e[s]     = V   (source voltage in RHS)
      case 'voltage-source': {
        const s = vsOffset + vsIdx  // row/col for this source's current unknown

        // B sub-matrix (stamp into column s of the G block)
        if (p >= 0) {
          stamp(aug, p, s, +1)  // B[p][s] = +1
          stamp(aug, s, p, +1)  // C[s][p] = +1  (C = B^T)
        }
        if (n >= 0) {
          stamp(aug, n, s, -1)  // B[n][s] = -1
          stamp(aug, s, n, -1)  // C[s][n] = -1
        }

        // RHS: e[s] = voltage source value
        aug[s][size] += el.value

        vsIdx++
        break
      }

      // ── Current source ──────────────────────────────────────────────
      // Stamps into the current injection vector i:
      //   i[p] -= I  (current leaves the positive terminal → subtract)
      //   i[n] += I  (current enters the negative terminal → add)
      case 'current-source': {
        if (p >= 0) aug[p][size] -= el.value
        if (n >= 0) aug[n][size] += el.value
        break
      }

      // ground is a reference only, no stamping
      case 'ground':
        break
    }
  }

  return { augmented: aug, size, vsOffset }
}
