// ─────────────────────────────────────────────────────────────────────────────
// matrix.ts — Dense matrix operations for MNA solving
//
// All matrix operations work on number[][] (row-major order).
// The MNA augmented matrix is (n × n+1) where the last column is the RHS.
//
// Algorithm: Gaussian elimination with partial pivoting (Doolittle LU).
// This is numerically stable for the matrix sizes we encounter (typically 2–20).
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Create an n×m zero matrix.
 */
export function zeros(n: number, m: number): number[][] {
  return Array.from({ length: n }, () => new Array<number>(m).fill(0))
}

/**
 * Create an n×n identity matrix.
 */
export function identity(n: number): number[][] {
  const I = zeros(n, n)
  for (let i = 0; i < n; i++) I[i][i] = 1
  return I
}

/**
 * Solve the linear system  A·x = b  using Gaussian elimination
 * with partial pivoting on the augmented matrix [A | b].
 *
 * @param aug  n×(n+1) augmented matrix — MODIFIED IN PLACE during elimination
 * @returns    solution vector x of length n, or null if singular
 */
export function gaussianElimination(aug: number[][]): number[] | null {
  const n = aug.length
  if (n === 0) return []

  // Forward elimination with partial pivoting
  for (let col = 0; col < n; col++) {
    // ── Find pivot row ─────────────────────────────────────────
    let pivotRow = col
    let maxAbs = Math.abs(aug[col][col])
    for (let row = col + 1; row < n; row++) {
      const a = Math.abs(aug[row][col])
      if (a > maxAbs) {
        maxAbs = a
        pivotRow = row
      }
    }

    // Singular check — pivot effectively zero
    if (maxAbs < 1e-14) return null

    // ── Swap rows ──────────────────────────────────────────────
    if (pivotRow !== col) {
      const tmp = aug[col]
      aug[col] = aug[pivotRow]
      aug[pivotRow] = tmp
    }

    const pivotVal = aug[col][col]

    // ── Eliminate below ────────────────────────────────────────
    for (let row = col + 1; row < n; row++) {
      const factor = aug[row][col] / pivotVal
      if (factor === 0) continue
      for (let k = col; k <= n; k++) {
        aug[row][k] -= factor * aug[col][k]
      }
    }
  }

  // Back substitution
  const x = new Array<number>(n).fill(0)
  for (let row = n - 1; row >= 0; row--) {
    let sum = aug[row][n] // RHS
    for (let col = row + 1; col < n; col++) {
      sum -= aug[row][col] * x[col]
    }
    const diag = aug[row][row]
    if (Math.abs(diag) < 1e-14) return null
    x[row] = sum / diag
  }

  return x
}

/**
 * Deep-clone a 2D matrix (so the solver doesn't mutate the original).
 */
export function cloneMatrix(m: number[][]): number[][] {
  return m.map((row) => [...row])
}

/**
 * Add scalar value to matrix element [r][c].
 * Convenience used heavily during MNA stamping.
 */
export function stamp(m: number[][], r: number, c: number, val: number): void {
  m[r][c] += val
}
