// ─────────────────────────────────────────────────────────────────────────────
// graph.ts — Circuit graph builder
//
// Converts the visual representation (CircuitNode[], Wire[]) into a Netlist
// (electrical graph) that the MNA solver can work with.
//
// Topology rules:
//   • Each CircuitNode has two terminals: "positive" (+) and "negative" (−)
//   • A Wire connecting two nodes merges their connected terminals
//     into the same netlist node (same electrical junction)
//   • Unconnected terminals float — treated as open circuit
//   • Ground nodes set the reference potential (0 V)
//
// Terminal naming convention:
//   `{componentId}_p`  = positive terminal
//   `{componentId}_n`  = negative terminal
//
// Junction merging uses a Union-Find (disjoint-set) structure so wire
// chains of any length are resolved in near-linear time.
// ─────────────────────────────────────────────────────────────────────────────

import type { CircuitNode, Wire } from '@/types'
import type { Netlist, NetlistElement, ElementKind } from './types'
import { parseValue } from '@/utils/units'

// ── Union-Find ────────────────────────────────────────────────────────────────

class UnionFind {
  private parent: Map<string, string> = new Map()
  private rank: Map<string, number> = new Map()

  private ensure(id: string): void {
    if (!this.parent.has(id)) {
      this.parent.set(id, id)
      this.rank.set(id, 0)
    }
  }

  find(id: string): string {
    this.ensure(id)
    // Path compression
    if (this.parent.get(id) !== id) {
      this.parent.set(id, this.find(this.parent.get(id)!))
    }
    return this.parent.get(id)!
  }

  union(a: string, b: string): void {
    const ra = this.find(a)
    const rb = this.find(b)
    if (ra === rb) return
    const rankA = this.rank.get(ra) ?? 0
    const rankB = this.rank.get(rb) ?? 0
    if (rankA < rankB) {
      this.parent.set(ra, rb)
    } else if (rankA > rankB) {
      this.parent.set(rb, ra)
    } else {
      this.parent.set(rb, ra)
      this.rank.set(ra, rankA + 1)
    }
  }

  /** Return the canonical representative id for a terminal */
  root(id: string): string {
    return this.find(id)
  }
}

// ── Terminal helpers ───────────────────────────────────────────────────────────

const posPin = (id: string) => `${id}_p`
const negPin = (id: string) => `${id}_n`

// ── Main builder ──────────────────────────────────────────────────────────────

/**
 * Build an electrical Netlist from the visual scene description.
 *
 * A Wire connects the positive terminal of its `from` component to the
 * negative terminal of its `to` component. (Convention: from = source end,
 * to = sink end — but either direction works electrically.)
 */
export function buildNetlist(
  visualNodes: CircuitNode[],
  wires: Wire[]
): Netlist {
  const uf = new UnionFind()

  // ── 1. Register all terminals ───────────────────────────────────────────────
  for (const vn of visualNodes) {
    uf.find(posPin(vn.id))
    uf.find(negPin(vn.id))
    // Ground nodes: their two terminals both become the same root
    if (vn.type === 'ground') {
      uf.union(posPin(vn.id), negPin(vn.id))
    }
  }

  // ── 2. Merge terminals connected by wires ────────────────────────────────────
  // Each wire connects the positive pin of `from` to the negative pin of `to`.
  // This models: wire.from's + terminal is at the same potential as
  // wire.to's − terminal (conventional current flow direction).
  for (const wire of wires) {
    uf.union(posPin(wire.from), negPin(wire.to))
    // Also union the `to` positive with the `from` negative so bidirectional
    // chains resolve: from_p — wire — to_n — (next wire) — next_p …
    // If the wire is undirected (both ends same component), short-circuit.
    if (wire.from === wire.to) {
      uf.union(posPin(wire.from), negPin(wire.from))
    }
  }

  // ── 3. Identify the ground junction ─────────────────────────────────────────
  // Priority: explicit 'ground' component → voltage-source negative → first node
  let groundRoot: string | undefined

  const groundNode = visualNodes.find((n) => n.type === 'ground')
  if (groundNode) {
    groundRoot = uf.root(posPin(groundNode.id))
  }

  if (!groundRoot) {
    const vsNode = visualNodes.find((n) => n.type === 'voltage-source')
    if (vsNode) {
      groundRoot = uf.root(negPin(vsNode.id))
    }
  }

  if (!groundRoot && visualNodes.length > 0) {
    groundRoot = uf.root(negPin(visualNodes[0].id))
  }

  if (!groundRoot) {
    groundRoot = '__ground__'
    uf.find(groundRoot)
  }

  // ── 4. Collect all unique junction roots (excluding ground) ─────────────────
  const allRoots = new Set<string>()
  for (const vn of visualNodes) {
    allRoots.add(uf.root(posPin(vn.id)))
    allRoots.add(uf.root(negPin(vn.id)))
  }

  const nodeMap = new Map<string, { id: string; index: number }>()
  let nodeIdx = 0

  for (const root of allRoots) {
    if (root === groundRoot) continue
    nodeMap.set(root, { id: root, index: nodeIdx++ })
  }

  const nodeCount = nodeIdx

  // ── 5. Build element list ────────────────────────────────────────────────────
  const elements: NetlistElement[] = []
  let vsCount = 0

  for (const vn of visualNodes) {
    if (vn.type === 'ground') continue  // ground is a reference marker only

    const pRoot = uf.root(posPin(vn.id))
    const nRoot = uf.root(negPin(vn.id))

    // Skip floating components (both terminals in the same junction including
    // components where neither terminal is connected to anything else)
    // — they don't affect the circuit solution.

    const kind = vn.type as ElementKind
    let value = 0

    switch (vn.type) {
      case 'resistor':
        value = parseValue(vn.properties.value ?? '1000')
        if (!isFinite(value) || value <= 0) value = 1000 // default 1kΩ
        break
      case 'voltage-source':
        value = parseValue(vn.properties.voltage ?? '9')
        if (!isFinite(value)) value = 9
        vsCount++
        break
      case 'capacitor':
        // For DC steady-state: capacitor = open circuit (infinite impedance)
        // We model it as a very large resistor to avoid open-circuit singularity.
        value = 1e12 // 1 TΩ effective
        break
      case 'inductor':
        // For DC steady-state: inductor = short circuit (zero impedance)
        value = 1e-6 // 1 µΩ effective
        break
      case 'wire':
        value = 1e-9 // near-zero resistance
        break
      default:
        value = 1000
    }

    elements.push({
      componentId: vn.id,
      kind,
      nodePos: pRoot,
      nodeNeg: nRoot,
      value,
    })
  }

  return {
    nodes: nodeMap,
    elements,
    groundId: groundRoot,
    nodeCount,
    voltageSourceCount: vsCount,
  }
}
