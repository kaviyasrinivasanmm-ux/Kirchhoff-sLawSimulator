// ─────────────────────────────────────────────────────────────────────────────
// physics/types.ts — simulation-domain types
//
// These are intentionally separate from the UI domain types in src/types/index.ts
// so the physics layer has no dependency on rendering or interaction concerns.
// ─────────────────────────────────────────────────────────────────────────────

// ── Netlist (graph representation of a circuit) ───────────────────────────────

/**
 * A netlist node is an electrical junction — a point where two or more
 * component terminals connect. Not to be confused with a CircuitNode (visual).
 */
export interface NetlistNode {
  /** Unique junction identifier (usually the visual component id + pin suffix) */
  id: string
  /** Index into the MNA node-voltage array (0 = ground, excluded from matrix) */
  index: number
}

/** Supported passive element types in the netlist */
export type ElementKind =
  | 'resistor'
  | 'voltage-source'
  | 'current-source'
  | 'capacitor'
  | 'inductor'
  | 'wire'     // ideal wire = 0-ohm connection (short circuit)
  | 'ground'   // reference node marker

/**
 * A single two-terminal element in the netlist.
 */
export interface NetlistElement {
  /** Visual component id this element originates from */
  componentId: string
  kind: ElementKind
  /** Positive terminal node id */
  nodePos: string
  /** Negative terminal node id */
  nodeNeg: string
  /**
   * Element value in base SI units:
   *   resistor       → Ω
   *   voltage-source → V
   *   current-source → A
   *   capacitor      → F
   *   inductor       → H
   */
  value: number
}

/**
 * The complete structural description of a circuit, ready for MNA stamping.
 */
export interface Netlist {
  /** All unique junction nodes (excludes ground pseudo-node) */
  nodes: Map<string, NetlistNode>
  /** All circuit elements */
  elements: NetlistElement[]
  /**
   * The reference (ground) node id.
   * All voltages are measured relative to this node.
   */
  groundId: string
  /** Number of non-ground nodes = dimension of the voltage sub-matrix */
  nodeCount: number
  /** Number of independent voltage sources = extra rows/cols in MNA */
  voltageSourceCount: number
}

// ── MNA matrix ────────────────────────────────────────────────────────────────

/**
 * The assembled MNA system  [ G  B ] [v]   [i]
 *                           [ C  D ] [j] = [e]
 *
 * Where:
 *   G = conductance sub-matrix (n×n, n = non-ground node count)
 *   B = voltage-source incidence (n×m, m = voltage source count)
 *   C = transpose of B (m×n)
 *   D = zero matrix for ideal voltage sources
 *   v = unknown node voltages
 *   j = unknown branch currents through voltage sources
 *   i = known current injections into each node
 *   e = known voltage source values
 *
 * Stored as one dense (n+m)×(n+m+1) augmented matrix for Gaussian elimination.
 */
export interface MNASystem {
  /** Augmented matrix [A | b], size (n+m) × (n+m+1) */
  augmented: number[][]
  /** Total unknowns = nodeCount + voltageSourceCount */
  size: number
  /** Index of the first voltage-source current unknown in the solution vector */
  vsOffset: number
}

// ── Simulation results ────────────────────────────────────────────────────────

/**
 * Per-node voltage result (node voltages relative to ground).
 */
export interface NodeVoltage {
  nodeId: string
  voltage: number  // volts
}

/**
 * Per-element (branch) result.
 */
export interface BranchResult {
  componentId: string
  /** Current flowing from nodePos → nodeNeg (conventional current) */
  current: number   // amperes
  /** Voltage drop across the element: V(nodePos) - V(nodeNeg) */
  voltageDrop: number  // volts
  /** Power consumed (positive) or supplied (negative) */
  power: number     // watts
}

/**
 * Complete result set for one simulation step.
 */
export interface SimulationResult {
  /** Whether the circuit was solvable (false = open/degenerate) */
  converged: boolean
  /** Error description when converged = false */
  error?: string
  /** Absolute voltages at each junction (relative to ground) */
  nodeVoltages: Map<string, number>
  /** Per-component electrical results */
  branches: Map<string, BranchResult>
  /** Simulation timestamp (performance.now()) */
  timestamp: number
}

// ── Simulation state (stored in zustand) ─────────────────────────────────────

export interface SimulationState {
  running: boolean
  result: SimulationResult | null
  tickCount: number
  /** ms between simulation updates (0 = run every animation frame) */
  intervalMs: number
}
