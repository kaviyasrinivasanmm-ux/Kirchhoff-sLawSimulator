import type { CircuitNode, Wire } from '@/types'
import type { SimulationResult, BranchResult } from './types'
import { buildNetlist } from './graph'
import { assembleMNA } from './mna'
import { gaussianElimination, cloneMatrix } from './matrix'
import { parseValue } from '@/utils/units'

export function solveCircuit(
  nodes: CircuitNode[],
  wires: Wire[]
): SimulationResult {
  const timestamp = performance.now()
  const empty: SimulationResult = {
    converged: false,
    error: 'No components',
    nodeVoltages: new Map(),
    branches: new Map(),
    timestamp,
  }

  if (nodes.length === 0) return empty

  const netlist = buildNetlist(nodes, wires)
  if (netlist.nodeCount === 0) {
    return { ...empty, error: 'No connected nodes — add wires to connect components' }
  }

  const mna = assembleMNA(netlist)
  if (mna.size === 0) {
    return { ...empty, error: 'Empty circuit matrix' }
  }

  const solution = gaussianElimination(cloneMatrix(mna.augmented))
  if (!solution) {
    return { ...empty, error: 'Singular matrix — circuit may be open or short-circuited' }
  }

  // Build node-voltage map: root → voltage
  const nodeVoltages = new Map<string, number>()
  nodeVoltages.set(netlist.groundId, 0)

  for (const [root, node] of netlist.nodes) {
    nodeVoltages.set(root, solution[node.index] ?? 0)
  }

  // Compute per-branch results
  const branches = new Map<string, BranchResult>()
  let vsIdx = 0

  for (const el of netlist.elements) {
    const vPos = nodeVoltages.get(el.nodePos) ?? 0
    const vNeg = nodeVoltages.get(el.nodeNeg) ?? 0
    const voltageDrop = vPos - vNeg
    let current = 0

    if (el.kind === 'voltage-source') {
      current = solution[mna.vsOffset + vsIdx] ?? 0
      vsIdx++
    } else if (el.value !== 0) {
      current = voltageDrop / el.value
    }

    branches.set(el.componentId, {
      componentId: el.componentId,
      current,
      voltageDrop,
      power: voltageDrop * current,
    })
  }

  // Map junction roots back to component IDs for UI consumption
  const componentVoltages = new Map<string, number>()
  for (const node of nodes) {
    if (node.type === 'ground') continue
    const pRoot = netlist.nodes.has(`${node.id}_p`)
      ? `${node.id}_p`
      : netlist.groundId
    // Find the root voltage
    for (const [root, nv] of netlist.nodes) {
      if (root.startsWith(node.id)) {
        componentVoltages.set(node.id, solution[nv.index] ?? 0)
        break
      }
    }
  }

  return {
    converged: true,
    nodeVoltages,
    branches,
    timestamp,
  }
}

export type { SimulationResult, BranchResult }
